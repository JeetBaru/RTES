/*************************************************************
 *  Author	: Jeet Baru
 ************************************************************/
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <semaphore.h>
#include <pthread.h>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace cv;
using namespace std;

#define HRES 480
#define VRES 360
#define DEADLINE 400
#define NSEC_PER_SEC (1000000000)
#define NSEC_PER_MSEC (1000000)
#define NSEC_PER_MICROSEC (1000)

struct timespec start_time = {0, 0};
struct timespec scheduleStop_time = {0, 0};
struct timespec exec_time ={0,0};

pthread_t canny_thread;
pthread_t houghLine_thread;
pthread_t houghElip_thread;
//pthread_t main_thread;

/*Thread Attributes*/
pthread_attr_t canny_thread_attr;
pthread_attr_t houghLine_thread_attr;
pthread_attr_t houghElip_thread_attr;
pthread_attr_t main_thread_attr;

struct sched_param canny_param;
struct sched_param houghLine_param;
struct sched_param houghElip_param;

/*Semaphores*/
sem_t sem1, sem2, sem3;

pthread_mutex_t rsrcA;

// Transform display window
char timg_window_name[] = "Edge Detector Transform";

int lowThreshold=0;
int const max_lowThreshold = 100;
int kernel_size = 3;
int edgeThresh = 1;
int ratio = 3;
int frameCnt = 0;
int totalExecTime = 0;

Mat canny_frame, cdst, timg_gray, timg_grad;
CvCapture* capture;
IplImage* frame;

/***************************************
*Function to find the time difference
***************************************/
int delta_t(struct timespec *stop, struct timespec *start, struct timespec *delta_t)
{
  int dt_sec=stop->tv_sec - start->tv_sec;		//Gives the time difference
  int dt_nsec=stop->tv_nsec - start->tv_nsec;

  if(dt_sec >= 0)
  {
    if(dt_nsec >= 0)
    {
      delta_t->tv_sec=dt_sec;
      delta_t->tv_nsec=dt_nsec;
    }
    else
    {
      delta_t->tv_sec=dt_sec-1;
      delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
    }
  }
  else
  {
    if(dt_nsec >= 0)
    {
      delta_t->tv_sec=dt_sec;
      delta_t->tv_nsec=dt_nsec;
    }
    else
    {
      delta_t->tv_sec=dt_sec-1;
      delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
    }
  }

  return(1);
}

/****************************************
*Function to print the Scheduling Policy
****************************************/
void print_scheduler(void)
{
   int schedType;

   schedType = sched_getscheduler(getpid());

   switch(schedType)
   {
     case SCHED_FIFO:
           printf("Pthread Policy is SCHED_FIFO\n");
           break;
     case SCHED_OTHER:
           printf("Pthread Policy is SCHED_OTHER\n");
       break;
     case SCHED_RR:
           printf("Pthread Policy is SCHED_OTHER\n");
           break;
     default:
       printf("Pthread Policy is UNKNOWN\n");
   }
}

/************************************************************
* Function to perform canny transformation for edge detection
*************************************************************/
void CannyThreshold(int, void*)
{
    Mat mat_frame(frame);

    cvtColor(mat_frame, timg_gray, CV_RGB2GRAY);

    /// Reduce noise with a kernel 3x3
    blur( timg_gray, canny_frame, Size(3,3) );

    /// Canny detector
    Canny( canny_frame, canny_frame, lowThreshold, lowThreshold*ratio, kernel_size );

    /// Using Canny's output as a mask, we display our result
    timg_grad = Scalar::all(0);

    mat_frame.copyTo( timg_grad, canny_frame);

    imshow( timg_window_name, timg_grad );

}

void *canny(void *threadp)
{	
	while(frameCnt <= 300)
    {
		sem_wait(&sem1);													//Waits for Semaphore
		frameCnt++;
		pthread_mutex_lock(&rsrcA);											//mutex lock 
        frame=cvQueryFrame(capture);
		pthread_mutex_unlock(&rsrcA);										//mutex lock 
        if(!frame) break;


        CannyThreshold(0, 0);
        char q = cvWaitKey(10);
        if( q == 'q' )
        {
            printf("got quit\n"); 
            break;
        }		
        sem_post(&sem2);
    }
}

/************************************************************
* Function to perform HoughLine transformation for edge detection
*************************************************************/

void *houghLineThreshold(void *threadp)
{
	vector<Vec4i> lines;
	while(frameCnt <= 300)
    {
		sem_wait(&sem2);
		frameCnt++;
		pthread_mutex_lock(&rsrcA);
        frame=cvQueryFrame(capture);
		pthread_mutex_unlock(&rsrcA);

        Mat mat_frame(frame);
        Canny(mat_frame, canny_frame, 50, 200, 3);

        HoughLinesP(canny_frame, lines, 1, CV_PI/180, 50, 50, 10);

        for( size_t i = 0; i < lines.size(); i++ )
        {
          Vec4i l = lines[i];
          line(mat_frame, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(0,0,255), 3, CV_AA);
        }

     
        if(!frame) break;

        cvShowImage("houghLineInteractive", frame);
		char c = cvWaitKey(10);
        if( c == 27 ) break;
        sem_post(&sem3);
    }
	
}

/************************************************************
* Function to perform Hough Eliptical transformation for edge detection
*************************************************************/

void *houghElipThreshold(void *threadp)
{
	Mat gray;
	vector<Vec3f> circles;
	while(frameCnt <= 300)
    {
		sem_wait(&sem3);
		frameCnt++;
		pthread_mutex_lock(&rsrcA);
        frame=cvQueryFrame(capture);
		pthread_mutex_unlock(&rsrcA);

        Mat mat_frame(frame);
        cvtColor(mat_frame, gray, CV_BGR2GRAY);
        GaussianBlur(gray, gray, Size(9,9), 2, 2);

        HoughCircles(gray, circles, CV_HOUGH_GRADIENT, 1, gray.rows/8, 100, 50, 0, 0);

        for( size_t i = 0; i < circles.size(); i++ )
        {
          Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
          int radius = cvRound(circles[i][2]);
          circle( mat_frame, center, 3, Scalar(0,255,0), -1, 8, 0 );
          circle( mat_frame, center, radius, Scalar(0,0,255), 3, 8, 0 );
        }

     
        if(!frame) break;

        cvShowImage("houghLineEliptical", frame);
		char c = cvWaitKey(10);
        if( c == 27 ) break;
			sem_post(&sem1);
	}	
}

/****************************************
*Main function
****************************************/
int main (int argc, char *argv[])
{
	int rc = -1,scope;
	int rt_max_prio, rt_min_prio;
	int dev=0;
	float totalExecTime = 0;
	cpu_set_t cpuset;
    CPU_SET(1, &cpuset);	
	
	/*Initialize Semaphore*/
	sem_init(&sem1, 0, 1);
	sem_init(&sem2, 0 ,0);
	sem_init(&sem3, 0 ,0);	
	
   // Set default protocol for mutex
   pthread_mutex_init(&rsrcA, NULL);
   
	/*Knowing Priority Values*/
	rt_max_prio = sched_get_priority_max(SCHED_FIFO);
	rt_min_prio = sched_get_priority_min(SCHED_FIFO);
	printf("rt_max_prio=%d\n", rt_max_prio);
	printf("rt_min_prio=%d\n", rt_min_prio);
	printf("Before Changing Scheduling\n");
	print_scheduler();

	canny_param.sched_priority = rt_max_prio;
	houghLine_param.sched_priority = rt_max_prio - 1;
	houghElip_param.sched_priority = rt_max_prio - 2;

	
	/*Initialize Sceduling Attributes*/
	pthread_attr_init(&canny_thread_attr);
	pthread_attr_init(&houghLine_thread_attr);
	pthread_attr_init(&houghElip_thread_attr);	
	
	/*Assigning Scheduling policy of threads*/
	pthread_attr_setinheritsched(&canny_thread_attr, PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy(&canny_thread_attr, SCHED_FIFO);
	rc=pthread_attr_setaffinity_np(&canny_thread_attr, sizeof(cpu_set_t), &cpuset);
	if(rc<0)
	{
		perror("pthread_setaffinity_np");
	}

	pthread_attr_setinheritsched(&houghLine_thread_attr, PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy(&houghLine_thread_attr, SCHED_FIFO);
	rc=pthread_attr_setaffinity_np(&houghLine_thread_attr, sizeof(cpu_set_t), &cpuset);
	if(rc<0)
	{
		perror("pthread_setaffinity_np");
	}
	
	pthread_attr_setinheritsched(&houghElip_thread_attr, PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy(&houghElip_thread_attr, SCHED_FIFO);	
	rc=pthread_attr_setaffinity_np(&houghElip_thread_attr, sizeof(cpu_set_t), &cpuset);
	if(rc<0)
	{
		perror("pthread_setaffinity_np");
	}
	
	pthread_attr_setschedparam(&canny_thread_attr, &canny_param);
	pthread_attr_setschedparam(&houghLine_thread_attr, &houghLine_param);	
	pthread_attr_setschedparam(&houghElip_thread_attr, &houghElip_param);
	
	 /*Changing Schedular Type*/
	rc=sched_setscheduler(getpid(), SCHED_FIFO, &canny_param);
	if(rc < 0) perror("nrt_param");
 
	printf("After Changing Scheduling\n");
	print_scheduler();
	
    /*Knowing the scope of Main*/
    pthread_attr_getscope(&main_thread_attr, &scope);
    if(scope == PTHREAD_SCOPE_SYSTEM)
        printf("PTHREAD SCOPE SYSTEM\n");
    else if (scope == PTHREAD_SCOPE_PROCESS)
        printf("PTHREAD SCOPE PROCESS\n");
    else
        printf("PTHREAD SCOPE UNKNOWN\n");

    if(argc > 1)
    {
        sscanf(argv[1], "%d", &dev);
        printf("using %s\n", argv[1]);
    }
    else if(argc == 1)
        printf("using default\n");

    else
    {
        printf("usage: capture [dev]\n");
        exit(-1);
    }	
	
    namedWindow( timg_window_name, CV_WINDOW_AUTOSIZE );	
	namedWindow( "houghLineInteractive", CV_WINDOW_AUTOSIZE );
	namedWindow( "houghLineEliptical", CV_WINDOW_AUTOSIZE );
	
	capture = (CvCapture *)cvCreateCameraCapture(dev);
    cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_WIDTH, HRES);
    cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_HEIGHT, VRES);	
	clock_gettime(CLOCK_REALTIME, &start_time);
	/*Create Threads*/
	rc = pthread_create( &canny_thread , &canny_thread_attr, canny , ( void * ) 0 ) ;
	if (rc)
   {
       printf("ERROR; pthread_create() 1 rc is %d\n", rc);
       perror(NULL);
       exit(-1);
   }
	rc = pthread_create( &houghLine_thread , &houghLine_thread_attr, houghLineThreshold, ( void * ) 0 ) ;
	if (rc)
   {
       printf("ERROR; pthread_create() 2 rc is %d\n", rc);
       perror(NULL);
       exit(-1);
   }
	rc = pthread_create( &houghElip_thread , &houghElip_thread_attr, houghElipThreshold, ( void * ) 0 ) ;
	if (rc)
   {
       printf("ERROR; pthread_create() 3 rc is %d\n", rc);
       perror(NULL);
       exit(-1);
   }	

    /*Join Threads to Main*/
    pthread_join ( canny_thread, NULL ) ;
    pthread_join ( houghLine_thread, NULL ) ;
    pthread_join ( houghElip_thread, NULL ) ;
	
	/*Get Stop Time*/
	clock_gettime(CLOCK_REALTIME, &scheduleStop_time);
	delta_t( &scheduleStop_time, &start_time, &exec_time);
	totalExecTime = float(exec_time.tv_sec*1000) + float( exec_time.tv_nsec/1000000);
	printf("\nTotal execution time:%f ms \n",totalExecTime);
	printf("Time taken to process one frame in all transformations in milliseconds is %f ms\n", (totalExecTime/100));
	printf("Expected deadline is %d \n",DEADLINE);
	printf("Jitter is %f\n", ((totalExecTime/100)-DEADLINE));
	if(pthread_mutex_destroy(&rsrcA) != 0)
     perror("mutex A destroy");
 
	cvReleaseCapture(&capture);
	cvDestroyWindow(timg_window_name);
	cvDestroyWindow("houghLineInteractive");
	cvDestroyWindow("houghLineEliptical");

};	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
