/*
 *
 *  Example by Sam Siewert : Canny Threshold
 *
 */
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace cv;
using namespace std;

#define HRES 320
#define VRES 240

#define NSEC_PER_SEC (1000000000)
#define NSEC_PER_MSEC (1000000)
#define NSEC_PER_MICROSEC (1000)

// Transform display window
char timg_window_name[] = "Edge Detector Transform";

int lowThreshold=0;
int const max_lowThreshold = 100;
int kernel_size = 3;
int edgeThresh = 1;
int ratio = 3;
Mat canny_frame, cdst, timg_gray, timg_grad;

IplImage* frame;

struct timespec start_time = {0, 0};
struct timespec scheduleStop_time = {0, 0};
struct timespec exec_time ={0,0};

/***************************************
*Function to find the time difference
***************************************/
int delta_t(struct timespec *stop, struct timespec *start, struct timespec *delta_t)
{
  int dt_sec=stop->tv_sec - start->tv_sec;		//Gives the time difference
  int dt_nsec=stop->tv_nsec - start->tv_nsec;

  if(dt_sec >= 0)
  {
    if(dt_nsec >= 0)
    {
      delta_t->tv_sec=dt_sec;
      delta_t->tv_nsec=dt_nsec;
    }
    else
    {
      delta_t->tv_sec=dt_sec-1;
      delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
    }
  }
  else
  {
    if(dt_nsec >= 0)
    {
      delta_t->tv_sec=dt_sec;
      delta_t->tv_nsec=dt_nsec;
    }
    else
    {
      delta_t->tv_sec=dt_sec-1;
      delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
    }
  }
  return(1);
}

void CannyThreshold(int, void*)
{
    Mat mat_frame(frame);

    cvtColor(mat_frame, timg_gray, CV_RGB2GRAY);

    /// Reduce noise with a kernel 3x3
    blur( timg_gray, canny_frame, Size(3,3) );

    /// Canny detector
    Canny( canny_frame, canny_frame, lowThreshold, lowThreshold*ratio, kernel_size );

    /// Using Canny's output as a mask, we display our result
    timg_grad = Scalar::all(0);

    mat_frame.copyTo( timg_grad, canny_frame);

    imshow( timg_window_name, timg_grad );

}


int main( int argc, char** argv )
{
    CvCapture* capture;
    int dev = 0,framecount = 0;
	float totalExecTime = 0;
    if(argc > 1)
    {
        sscanf(argv[1], "%d", &dev);
        printf("using %s\n", argv[1]);
    }
    else if(argc == 1)
        printf("using default\n");

    else
    {
        printf("usage: capture [dev]\n");
        exit(-1);
    }

    namedWindow( timg_window_name, CV_WINDOW_AUTOSIZE );
    // Create a Trackbar for user to enter threshold
    createTrackbar( "Min Threshold:", timg_window_name, &lowThreshold, max_lowThreshold, CannyThreshold );

    capture = (CvCapture *)cvCreateCameraCapture(dev);
    cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_WIDTH, HRES);
    cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_HEIGHT, VRES);

	/*Get Start Time*/
	clock_gettime(CLOCK_REALTIME, &start_time);													//get the start time
	
    while(framecount <= 100)
    {
        frame=cvQueryFrame(capture);
        if(!frame) break;


        CannyThreshold(0, 0);
		char q = cvWaitKey(10);
        if( q == 'q' )
        {
            printf("got quit\n"); 
            break;
        }
		framecount++;
    }
	
	/*Get Stop Time*/
	clock_gettime(CLOCK_REALTIME, &scheduleStop_time);
	delta_t( &scheduleStop_time, &start_time, &exec_time);
	totalExecTime = float(exec_time.tv_sec*1000) + float( exec_time.tv_nsec/1000000);
	printf("\nTotal execution time:%f ms \n",totalExecTime);
	printf("Time taken to process one frame in milliseconds is %f ms\n", (totalExecTime/100)); 
    cvReleaseCapture(&capture);
	cvDestroyWindow(timg_window_name);
    
};
