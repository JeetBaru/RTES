/******************************************************************************
Authors: Jeet Baru
Credits: Sam Siewert
******************************************************************************/
//           # mkdir /dev/mqueue
//           # mount -t mqueue none /dev/mqueue


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h>
#include <string.h>
#include <mqueue.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define SNDRCV_MQ "/send_receive_mq"
#define MAX_MSG_SIZE 128
#define ERROR (-1)
#define NUM_THREADS (2)
#define NUM_CPUS (1)

struct mq_attr mq_attr;        //attribute
static mqd_t mymq;             //global message queue
static char imagebuff[10];   
typedef struct                 
{
    int threadIdx;
} threadParams_t;             

pthread_t threads[NUM_THREADS];
threadParams_t threadParams[NUM_THREADS];
pthread_attr_t rt_sched_attr[NUM_THREADS];
int rt_max_prio, rt_min_prio;
struct sched_param rt_param[NUM_THREADS];
struct sched_param main_param;
pthread_attr_t main_attr;
pid_t mainpid;


/***********Finding time difference******************/
void print_scheduler(void)
{
   int schedType;

   schedType = sched_getscheduler(getpid());

   switch(schedType)
   {
     case SCHED_FIFO:
           printf("Pthread Policy is SCHED_FIFO\n");
           break;
     case SCHED_OTHER:
           printf("Pthread Policy is SCHED_OTHER\n");
       break;
     case SCHED_RR:
           printf("Pthread Policy is SCHED_OTHER\n");
           break;
     default:
       printf("Pthread Policy is UNKNOWN\n");
   }

}
/*******************************************************/


/****************Receiver thread**********************/
void *receiver(void)
{
  mqd_t mymq;
  char buffer[sizeof(void *)+sizeof(int)];
  int prio;
  int nbytes;
  void *buffptr;
  int count = 0;
  int id;
    /* read oldest, highest priority msg from the message queue */
    printf("Reading %ld bytes\n", sizeof(void *));
  mymq = mq_open(SNDRCV_MQ, O_CREAT|O_RDWR, 0664, &mq_attr); 
 if((nbytes = mq_receive(mymq, buffer, (size_t)(sizeof(void *)+sizeof(int)), &prio)) == ERROR)
 //if((nbytes = mq_receive(mymq, (void *)&buffptr, sizeof(void *), &prio)) == ERROR)

    {
      perror("mq_receive");
    }
    else
    {
      memcpy(&buffptr, buffer, sizeof(void *));
      memcpy((void *)&id, &(buffer[sizeof(void *)]), sizeof(int));
      printf("receive: ptr msg 0x%X received with priority = %d, length = %d, id = %d\n", buffptr, prio, nbytes, id);
      printf("contents of ptr = \n%s\n", (char *)buffptr);
      free(buffptr);
      printf("heap space memory freed\n");
    }
}
/*************************************************************/


/****************Sender thread*******************************/
void *sender(void)
{
  char buffer[sizeof(void *)+sizeof(int)];
  void *buffptr;
  int prio;
  int nbytes;
  int id = 999;


    /* send malloc'd message with priority=30 */
    buffptr = (void *)malloc(sizeof(imagebuff));
    strcpy(buffptr, imagebuff);
    mymq = mq_open(SNDRCV_MQ, O_CREAT|O_RDWR, S_IRWXU, &mq_attr);
    printf("Message to send = %s\n", (char *)buffptr);


    memcpy(buffer, &buffptr, sizeof(void *));
    memcpy(&(buffer[sizeof(void *)]), (void *)&id, sizeof(int));
    printf("Sending %ld bytes\n", sizeof(buffptr));
    if((nbytes = mq_send(mymq, buffer, (sizeof(void *)+sizeof(int)), 30)) == ERROR)
    {
      printf("hello\n");
      perror("mq_send");
    }
    else
    {
      printf("send: message ptr 0x%X successfully sent\n", buffptr);
    }
  
}
/***************************************************************/



void main(int argc, char *argv[])
{
   int i, j;
  char pixel = 'A';
   for(i=0;i<10;i+=2) 
  {
    pixel = 'A';
    for(j=i;j<i+64;j++)
    {
      imagebuff[j] = (char)pixel++;  //storing message to be transferred in an array
    }
    imagebuff[j-1] = '\n';
  }
  imagebuff[10] = '\0';
  //imagebuff[] = '\0';

  printf("buffer =%s\n", imagebuff);
  /* setup common message q attributes */
  mq_attr.mq_maxmsg = 100;              //in attributes structure giving the max no of messages
  mq_attr.mq_msgsize =sizeof(void *)+sizeof(int);   //specifing size(no of bytes) of each message

  mq_attr.mq_flags = 0; //message queue flag   
    
 mymq = mq_open(SNDRCV_MQ, O_CREAT|O_RDWR, 0664, &mq_attr);  //opening message queue

  if(mymq < 0)
  {
    perror("error in setup mq_open");
    exit(-1);
  }
  else
  {
    printf(" opened mq\n");   //message queue correctly opened
  }

  // Create two communicating processes right here
  int rc;
   int scope;
   cpu_set_t cpuset;

   mainpid=getpid();

   rt_max_prio = sched_get_priority_max(SCHED_FIFO);
   rt_min_prio = sched_get_priority_min(SCHED_FIFO);

   print_scheduler();
   rc=sched_getparam(mainpid, &main_param);
   main_param.sched_priority=rt_max_prio;
   rc=sched_setscheduler(getpid(), SCHED_FIFO, &main_param);
   if(rc < 0) perror("main_param");
   print_scheduler();


   pthread_attr_getscope(&main_attr, &scope);

   if(scope == PTHREAD_SCOPE_SYSTEM)
     printf("PTHREAD SCOPE SYSTEM\n");
   else if (scope == PTHREAD_SCOPE_PROCESS)
     printf("PTHREAD SCOPE PROCESS\n");
   else
     printf("PTHREAD SCOPE UNKNOWN\n");

   printf("rt_max_prio=%d\n", rt_max_prio);
   printf("rt_min_prio=%d\n", rt_min_prio);

         for(i=0; i < NUM_THREADS; i++)
   {
       rc=pthread_attr_init(&rt_sched_attr[i]);
       rc=pthread_attr_setinheritsched(&rt_sched_attr[i], PTHREAD_EXPLICIT_SCHED);
       rc=pthread_attr_setschedpolicy(&rt_sched_attr[i], SCHED_FIFO);
       rc=pthread_attr_setaffinity_np(&rt_sched_attr[i], sizeof(cpu_set_t), &cpuset);

       rt_param[i].sched_priority=rt_max_prio-i-1;
       pthread_attr_setschedparam(&rt_sched_attr[i], &rt_param[i]);

       threadParams[i].threadIdx=i;

   }
//creating the sender and receiver threads
  pthread_create(&threads[0],   // pointer to thread descriptor
                      (void *)0,     // use default attributes
                      sender, // thread function entry point
                      (void *)&(threadParams[0]) // parameters to pass in
                     );


       pthread_create(&threads[1],   // pointer to thread descriptor
                      (void *)0,     // use default attributes
                      receiver, // thread function entry point
                      (void *)&(threadParams[1]) // parameters to pass in
                     );

   for(i=0;i<NUM_THREADS;i++)
       pthread_join(threads[i], NULL);  //waiting for the threads to end

   
}

