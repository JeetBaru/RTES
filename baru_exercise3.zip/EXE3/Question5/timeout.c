/******************************************************************************
Authors: Jeet BaruCredits: Sam Siewert
******************************************************************************/

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <sched.h>


#define NUM_THREADS (2)
#define NUM_CPUS (1)
#define NSEC_PER_SEC (1000000000)
#define NSEC_PER_MSEC (1000000)
#define NSEC_PER_MICROSEC (1000)


typedef struct    //defining structure to store the data
{
  struct timespec timestamp ;
  double X;
  double Y;
  double Z;
  double Yaw;
  double Pitch;
  double Roll;
}info_t ;

info_t info; 
struct timespec start_time = {0, 0};   //timespec to store start time 
pthread_mutex_t mymutex;               //global mutex

typedef struct
{
    int threadIdx;
} threadParams_t;

pthread_t threads[NUM_THREADS];
threadParams_t threadParams[NUM_THREADS];
pthread_attr_t rt_sched_attr[NUM_THREADS];
int rt_max_prio, rt_min_prio;
struct sched_param rt_param[NUM_THREADS];
struct sched_param main_param;
pthread_attr_t main_attr;
pid_t mainpid;

/***********Finding time difference******************/
int delta_t(struct timespec *stop, struct timespec *start, struct timespec *delta_t)
{
  int dt_sec=stop->tv_sec - start->tv_sec;
  int dt_nsec=stop->tv_nsec - start->tv_nsec;

  if(dt_sec >= 0)
  {
    if(dt_nsec >= 0)
    {
      delta_t->tv_sec=dt_sec;
      delta_t->tv_nsec=dt_nsec;
    }
    else
    {
      delta_t->tv_sec=dt_sec-1;
      delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
    }
  }
  else
  {
    if(dt_nsec >= 0)
    {
      delta_t->tv_sec=dt_sec;
      delta_t->tv_nsec=dt_nsec;
    }
    else
    {
      delta_t->tv_sec=dt_sec-1;
      delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
    }
  }

  return(1);
}
/*****************************************/

/***********Print scheduling policy***************/
void print_scheduler(void)
{
   int schedType;

   schedType = sched_getscheduler(getpid());

   switch(schedType)
   {
     case SCHED_FIFO:
           printf("Pthread Policy is SCHED_FIFO\n");
           break;
     case SCHED_OTHER:
           printf("Pthread Policy is SCHED_OTHER\n");
       break;
     case SCHED_RR:
           printf("Pthread Policy is SCHED_OTHER\n");
           break;
     default:
       printf("Pthread Policy is UNKNOWN\n");
   }
}
/************************************************/

/*********** Read Thread**********************/
void *read(void *threadp)
{
  double X,Y,Z,Yaw,Pitch,Roll,a;
  struct timespec stop_time = {0, 0};
  struct timespec wait_time1,wait_time2;
  for(a=0;a<4;a++)
  {
  clock_gettime(CLOCK_REALTIME, &wait_time1);
  wait_time2.tv_sec=wait_time1.tv_sec+10;
  pthread_mutex_timedlock(&mymutex,&wait_time2);
   clock_gettime(CLOCK_REALTIME, &stop_time);
  delta_t(&stop_time, &start_time, &info.timestamp);
  printf("No new data available at %d sec, %d nsec\n",info.timestamp.tv_sec,info.timestamp.tv_nsec);
   pthread_mutex_lock(&mymutex);
  clock_gettime(CLOCK_REALTIME, &stop_time);
  delta_t(&stop_time, &start_time, &info.timestamp);
  X=info.X;
  Y=info.Y;
  Z=info.Z;
   Yaw=info.Yaw;
   Pitch=info.Pitch;
   Roll=info.Roll;
   pthread_mutex_unlock(&mymutex);
printf("Read:\n");
printf("Time:%d sec, %d nsec\n",info.timestamp.tv_sec,info.timestamp.tv_nsec);
printf("Acceleration->X=%f Y=%f Z=%f Yaw=%f Pitch=%f Roll=%f\n",X,Y,Z,Yaw,Pitch,Roll);
 usleep(30);
 }
}
/******************************************************/

/************Update thread*****************************/
void *update(void *threadp)
{
   int i=0,j=1,a;
   struct timespec stop_time = {0, 0};
   for(a=0;a<4;a++)
   {
   pthread_mutex_lock(&mymutex);  //locking mutex
   info.X=i;                      //updating the structure
   info.Y=i;
   info.Z=i;
   info.Yaw=j;
   info.Pitch=j;
   info.Roll=j;
   sleep(20);                  //sleeping the thread for 20 sec
   clock_gettime(CLOCK_REALTIME, &stop_time);
   delta_t(&stop_time, &start_time, &info.timestamp);
   pthread_mutex_unlock(&mymutex);  //unlocking mutex
   i++;
   j++;
   printf("Updating:\n");
   printf("Time:%d sec, %d nsec\n",info.timestamp.tv_sec,info.timestamp.tv_nsec);
   printf("Acceleration->X=%f Y=%f Z=%f Yaw=%f Pitch=%f Roll=%f\n",info.X,info.Y,info.Z,info.Yaw,info.Pitch,info.Roll);
   usleep(20);
   }
}
/*****************************************************/

int main (int argc, char *argv[])
{
   int rc;
   int i, scope;
   cpu_set_t cpuset;

   mainpid=getpid();

   rt_max_prio = sched_get_priority_max(SCHED_FIFO);
   rt_min_prio = sched_get_priority_min(SCHED_FIFO);

   print_scheduler();
   rc=sched_getparam(mainpid, &main_param);
   main_param.sched_priority=rt_max_prio;
   rc=sched_setscheduler(getpid(), SCHED_FIFO, &main_param);
   if(rc < 0) perror("main_param");
   print_scheduler();


   pthread_attr_getscope(&main_attr, &scope);

   if(scope == PTHREAD_SCOPE_SYSTEM)
     printf("PTHREAD SCOPE SYSTEM\n");
   else if (scope == PTHREAD_SCOPE_PROCESS)
     printf("PTHREAD SCOPE PROCESS\n");
   else
     printf("PTHREAD SCOPE UNKNOWN\n");

   printf("rt_max_prio=%d\n", rt_max_prio);
   printf("rt_min_prio=%d\n", rt_min_prio);

         for(i=0; i < NUM_THREADS; i++)
   {
       rc=pthread_attr_init(&rt_sched_attr[i]);
       rc=pthread_attr_setinheritsched(&rt_sched_attr[i], PTHREAD_EXPLICIT_SCHED);
       rc=pthread_attr_setschedpolicy(&rt_sched_attr[i], SCHED_FIFO);
       rc=pthread_attr_setaffinity_np(&rt_sched_attr[i], sizeof(cpu_set_t), &cpuset);

       rt_param[i].sched_priority=rt_max_prio-i-1;
       pthread_attr_setschedparam(&rt_sched_attr[i], &rt_param[i]);

       threadParams[i].threadIdx=i;

   }

    pthread_mutex_init(&mymutex,NULL);           //intializing mutex
    clock_gettime(CLOCK_REALTIME, &start_time);  //get the clock start time
//calling the update thread and then the read thread
       pthread_create(&threads[0],   // pointer to thread descriptor
                      (void *)0,     // use default attributes
                      update, // thread function entry point
                      (void *)&(threadParams[i]) // parameters to pass in
                     );


       pthread_create(&threads[1],   // pointer to thread descriptor
                      (void *)0,     // use default attributes
                      read, // thread function entry point
                      (void *)&(threadParams[1]) // parameters to pass in
                     );

   for(i=0;i<NUM_THREADS;i++)
       pthread_join(threads[i], NULL);  //waiting for the threads to end
   pthread_mutex_destroy(&mymutex);

   printf("\nTEST COMPLETE\n");
}
