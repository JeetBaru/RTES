Compiled with Tornado 2.0.2 and run on x86 VxWorks 5.4.1.
