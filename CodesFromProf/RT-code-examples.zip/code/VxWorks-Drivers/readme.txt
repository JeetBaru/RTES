The VxWorks example drivers were compiled with Tornado 2.0.2 and VxWorks 5.4.1.
