This example code is incomplete and purposely contains some buffering bugs so that students may adapt and correct in order to add record capability and to analyze and correct buffering.  As is, the example only provides playback of a noisy/scratchy sound from a data array - the data array may be modified to further test and understand how playback works.

For a more complete example of this code adapted to include record and optional encryption on the link between two ends of a VOIP connection, please see:

RTECS-CDROM\Contributed\VOIP-with-encryption-example

This code is released under the GPL (GNU General Public license) and the LGPL (GNU Lesser General Public License).
