It is recommended that btvid-3 be used as it is the latest version with bug fixes for PCI interface.  All versions support only one video capture mode which is 320x240 alpha,R,G,B with 76800 pixels per frame, 32-bits/pixel.  Other video capture formats require adaptation of the example micro code.

btvid-1, and btvid-2 are provided as well for reference

btvid2-with-streaming includes example code to stream PPM format frames to the Vpipe Display TCP server as a TCP client

All code provided is to provide a starting point and example for how to interface to the Bt878 video encoder chip in VxWorks.

This code is released under the GPL (GNU General Public license) and the LGPL (GNU Lesser General Public License).

A more fully featured Linux driver is available from:

http://bttv-v4l2.sourceforge.net/
