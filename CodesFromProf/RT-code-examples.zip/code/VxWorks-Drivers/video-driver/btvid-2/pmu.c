#include "vxWorks.h"
#include "stdio.h"
#include "stdlib.h"
#include "ioLib.h"

/* This code will work on x86 Pentium machines which implement the Time Stamp
   Counter in  the x86 version of Performance Counters called the PMU.

   If not, please remove the #define below for 32-bit unsigned
   long declarations.
*/


#define FIB_LIMIT_FOR_32_BIT 47

typedef unsigned long long int UINT64;

#define INSTRUCTIONS_EXECUTED 0x16


#define	ENABLE_USR_RDPMC		__asm__ __volatile__ (		/* enabled when PCE bit set */ \
					"movl %%cr4,%%eax\n\t"\
					"orl $0x00000100,%%eax\n\t"\
					"movl %%eax,%%cr4"\
					: : : "eax")

#define	DISABLE_USR_RDPMC		__asm__ __volatile__ (		/* disabled when PCE bit clear */ \
					"movl %%cr4,%%eax\n\t"\
					"andl $0xfffffeff,%%eax\n\t"\
					"movl %%eax,%%cr4"\
					: : : "eax")



#define PMC_ASM(instructions,N,buf) \
  __asm__ __volatile__ ( instructions : "=A" (buf) : "c" (N) )

#define PMC_ASM_READ_TSC(buf) \
  __asm__ __volatile__ ( "rdtsc" : "=A" (buf) )

#define PMC_ASM_READ_PMC(N,buf) PMC_ASM("rdpmc",N,buf)




UINT64 startTSC = 0;
UINT64 stopTSC = 0;
UINT64 cycleCnt = 0;
UINT64 startICnt = 0;
UINT64 stopICnt = 0;


UINT64 readTSC(void)
{
   UINT64 ts;

   __asm__ volatile(".byte 0x0f,0x31" : "=A" (ts));
   return ts;
}


UINT64 readPMC(void)
{
   UINT64 pmc;

   __asm__ volatile(".byte 0x0f,0x33" : "=A" (pmc));
   return pmc;
}


UINT64 cyclesElapsed(UINT64 stopTS, UINT64 startTS)
{
   return (stopTS - startTS);
}

UINT32 idx = 0, jdx = 1;
UINT32 seqIterations = FIB_LIMIT_FOR_32_BIT;
UINT32 reqIterations = 1, Iterations = 1;
UINT32 fib = 0, fib0 = 0, fib1 = 1;

#define FIB_TEST(seqCnt, iterCnt)      \
   for(idx=0; idx < iterCnt; idx++)    \
   {                                   \
      fib = fib0 + fib1;               \
      while(jdx < seqCnt)              \
      {                                \
         fib0 = fib1;                  \
         fib1 = fib;                   \
         fib = fib0 + fib1;            \
         jdx++;                        \
      }                                \
   }                                   \


void fib_wrapper(void)
{
   FIB_TEST(seqIterations, Iterations);
}


#define INST_CNT_FIB_INNER 15
#define INST_CNT_FIB_OUTTER 6
 

int testpmu(void)
{
   UINT32 instCnt = 0;

   instCnt = (INST_CNT_FIB_INNER * seqIterations) +
             (INST_CNT_FIB_OUTTER * Iterations) + 1;



   /* Estimate CPU clock rate */
   startTSC = readTSC();
   sysClkRateSet(1000);
   taskDelay(1000);
   stopTSC = readTSC();
   cycleCnt = cyclesElapsed(stopTSC, startTSC);


   printf("Cycle Count=%lu\n", cycleCnt);

   printf("Based on sleep accuracy, CPU clk rate = %lu clks/sec,",
          cycleCnt);

   printf("\nRunning Fibbonaci(%d) Test for %ld iterations\n",
          seqIterations, Iterations);


   
   /* START Timed Fibbonaci Test */
   ENABLE_USR_RDPMC;

   pentiumPmcStart(INSTRUCTIONS_EXECUTED, INSTRUCTIONS_EXECUTED);
   pentiumPmcGet0(&startICnt);

   PMC_ASM_READ_TSC(startTSC);
   FIB_TEST(seqIterations, Iterations);
   PMC_ASM_READ_TSC(stopTSC);

   pentiumPmcGet0(&stopICnt);
   pentiumPmcStop();

   DISABLE_USR_RDPMC;
   /* END Timed Fibbonaci Test */


   printf("startTSC =0x%016x\n", startTSC);
   printf("stopTSC =0x%016x\n", stopTSC);

   cycleCnt = cyclesElapsed(stopTSC, startTSC);
   printf("\nFibbonaci(%lu)=%lu (0x%08lx)\n", seqIterations, fib, fib);
   printf("\nCycle Count=%llu\n", cycleCnt);
   printf("\nInst Count=%lu\n", instCnt);
   printf("\nPMU Inst Count=%lu\n", (stopICnt - startICnt));


}

