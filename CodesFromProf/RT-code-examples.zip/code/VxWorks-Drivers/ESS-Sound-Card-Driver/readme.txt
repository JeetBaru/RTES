The example ESS sound card driver for VxWorks was adapted from the ALSA Linux version for build with Tornado.

http://www.alsa-project.org/

The original driver and chip documents come from the ALSA driver download ftp site at: 

1) Manuals - ftp://ftp.alsa-project.org/pub/manuals/ess/

2) ftp://ftp.alsa-project.org/pub/driver/

ALSA is released under the GPL (GNU General Public license) and the LGPL (GNU Lesser General Public License).  As such, the derived VxWorks version also is released under the GPL and the LGPL.

The VxWorks version is provided as a reference and starting point for readers implementing driver support for the ESS sound card.

More information on the ESS device can be found at:

1) General info - http://www.esstech.com/
2) ESS Windows drivers - http://www.esstech.com/techsupp/drivers.shtm
