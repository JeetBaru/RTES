/****************************************************************
*
* MODULE:		vxLinSupport.cpp
*
* DESCRIPTION:	Generic VxWorks version of standard linux routines
*				
*				
* ORIGINAL AUTHOR: 	Dan Walkes - with several structure/data definitions
*						and code referenced from linux source tree
*					
* UPDATED BY:		
* 
* CREATED:		Nov, 2005
* MODIFIED:		
* 
* NOTES:
*

* CODE USAGE:
*
* REVISION HISTORY AND NOTES:
*
* Date			Update
* ---------------------------------------------------------------------
* Nov 13, 2005	Created.
*
* REFERENCES:
*
* 1) "vxWALSA Sound Driver" document included with this release.
*
****************************************************************/


/* Vxworks -linux includes */
#include "VxTypes.h"


/*--------------------------------------------------------------
	#defines
----------------------------------------------------------------*/

/*--------------------------------------------------------------
	Global Variables
----------------------------------------------------------------*/

/*--------------------------------------------------------------
	Function Prototypes
----------------------------------------------------------------*/

/*--------------------------------------------------------------
	Function Description:
		Locks interrupts and task switches for a critical section.
		Make sure to call vx_spin_lock_irqrestore at the end of
		the critical section.
		Be careful not to call vxWorks 
		
	
	Arguments:
		none
	
	Returns:
		unsigned long lockKey - lock out key returned by vxworks function
		intLock
---------------------------------------------------------------*/
unsigned long vx_spin_lock_irqsave( void )
{
	unsigned long lockKey;


	if( intContext() )
	{
		/* can't call from interrupt context */
		SYS_ASSERT( taskLock() == OK );
	}

    	lockKey = intLock ();

	return lockKey;	
}

/*--------------------------------------------------------------
	Function Description:
		Re-enables interrupts and task switches 
		Call this function after a call to vx_spin_lock_irqsave
	
	Arguments:
		none
	
	Returns:
		0 (success)		
---------------------------------------------------------------*/
int vx_spin_unlock_irqrestore( unsigned long lockKey )
{
	/* unlock the interrupts based on the last lock key */
    intUnlock (lockKey);
	if( !intContext() )
	{
		/* can't call from interrupt context */
	    SYS_ASSERT( taskUnlock() == OK );
	}

	return 0;
}


