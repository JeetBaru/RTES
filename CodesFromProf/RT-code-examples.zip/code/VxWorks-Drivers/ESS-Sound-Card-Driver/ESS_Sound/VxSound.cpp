/****************************************************************
*
* MODULE:		VxSound.cpp
*
* DESCRIPTION: 	A framework for porting ALSA library sound card drivers
*				to VxWorks.
*				
* ORIGINAL AUTHOR: 	Dan Walkes - with lots of influence from GNU ALSA
*					library files and linux sound driver code.
*					
* UPDATED BY:		
* 
* CREATED:		Oct, 2005
* MODIFIED:		
* 
* NOTES:
*
*	In most cases, functions without a vx_ prefix were taken from the ALSA library
*	files and modified little (if any) to work with VxWorks.  Functions starting with a
*	vx_ were changed significantly to support VxWorks instead of linux.
*
* CODE USAGE:
*	See references
*
* REVISION HISTORY AND NOTES:
*
* Date			Update
* ---------------------------------------------------------------------
* Oct 1, 2005	Created.
*
* REFERENCES:
*
* 1) "vxWALSA Sound Driver" document included with this release.
*
****************************************************************/

#include "vxworks.h"
#include "stdlib.h"
#include <stdio.h>
#include <string.h>

/* Vxworks -linux includes */
#include "VxTypes.h"
#include "VxPCI.h"
#include "VxSound.h"
#include "es1938.h"			  



/*--------------------------------------------------------------
	Global Variables
----------------------------------------------------------------*/

static int maximum_substreams = 4;
uint32 snd_interrupt=0;
snd_card_t	*psndCard;
static int preallocate_dma = 1;

/* variables for debugging/reference */
pci_dev *pGlobPCIDev;
snd_pcm_substream_t *gplayback;

/* include application .h files here */
#include "vx_tone_ap.h"

/* a structure with sound applications.. replace with your application.
	See vx_tone_ap for more information */
vx_snd_application	sndAp =
{
	{	TONE_PLAYBACK_PRIORITY, toneApPlaybackTaskInit },	// playback params
	{	0	}	// capture params
};

/*--------------------------------------------------------------
	Function Prototypes
----------------------------------------------------------------*/
static int snd_pcm_free(snd_pcm_t *pcm);
static int snd_pcm_lib_preallocate_pages1(snd_pcm_substream_t *substream,
					  size_t size, size_t max);
static int vx_snd_pcm_substream_proc_done( snd_pcm_substream_t *substream );
static int vx_snd_pcm_substream_proc_init( snd_pcm_substream_t *substream );


/*--------------------------------------------------------------
	Function Description:
		Allocates a new snd_card_t structure based on the passed parameters
		This function was taken directly from the ALSA library and includes lots
		of stuff specific to Linux in the  VXWORKS_UNUSED compile-switched section.

		Basically all this function does now is allocate the snd_card_t structure
		and initialize members.

		Call snd_card_free to free this structure.
	
	Arguments:
		int idx - not used
		const char *xid - not used
		void *module - not used
		int extra size - extra size allocated within the sound card structure
	
	Returns:
		snd_card_t * the new card or NULL if failure		
---------------------------------------------------------------*/

snd_card_t *snd_card_new( int idx, const char *xid, void *module, int extra_size)
{	

	snd_card_t *card;
	int err;

	if (extra_size < 0)
		extra_size = 0;
	card = (snd_card_t *) kcalloc(1, sizeof(*card) + extra_size, GFP_KERNEL);
	if (card == NULL)
		return NULL;

	card->private_free = NULL;

	return card;	/* note.. eventually may need to do some of the stuff below */
		
#if VXWORKS_UNUSED

	if (xid) {
		if (!snd_info_check_reserved_words(xid))
			goto __error;
		strlcpy(card->id, xid, sizeof(card->id));
	}
	err = 0;
	write_lock(&snd_card_rwlock);
	if (idx < 0) {
		int idx2;
		for (idx2 = 0; idx2 < SNDRV_CARDS; idx2++)
			if (~snd_cards_lock & idx & 1<<idx2) {
				idx = idx2;
				if (idx >= snd_ecards_limit)
					snd_ecards_limit = idx + 1;
				break;
			}
	} else if (idx < snd_ecards_limit) {
		if (snd_cards_lock & (1 << idx))
			err = -ENODEV;	/* invalid */
	} else if (idx < SNDRV_CARDS)
		snd_ecards_limit = idx + 1; /* increase the limit */
	else
		err = -ENODEV;
	if (idx < 0 || err < 0) {
		write_unlock(&snd_card_rwlock);
		snd_printk(KERN_ERR "cannot find the slot for index %d (range 0-%i)\n", idx, snd_ecards_limit - 1);
		goto __error;
	}
	snd_cards_lock |= 1 << idx;		/* lock it */
	write_unlock(&snd_card_rwlock);
	card->number = idx;
	card->module = module;
	INIT_LIST_HEAD(&card->devices);
	init_rwsem(&card->controls_rwsem);
	rwlock_init(&card->ctl_files_rwlock);
	INIT_LIST_HEAD(&card->controls);
	INIT_LIST_HEAD(&card->ctl_files);
	spin_lock_init(&card->files_lock);
	init_waitqueue_head(&card->shutdown_sleep);
	INIT_WORK(&card->free_workq, snd_card_free_thread, card);
#ifdef CONFIG_PM
	init_MUTEX(&card->power_lock);
	init_waitqueue_head(&card->power_sleep);
#endif
	/* the control interface cannot be accessed from the user space until */
	/* snd_cards_bitmask and snd_cards are set with snd_card_register */
	if ((err = snd_ctl_create(card)) < 0) {
		snd_printd("unable to register control minors\n");
		goto __error;
	}
	if ((err = snd_info_card_create(card)) < 0) {
		snd_printd("unable to create card info\n");
		goto __error_ctl;
	}
	if (extra_size > 0)
		card->private_data = (char *)card + sizeof(snd_card_t);
	return card;

      __error_ctl:
	snd_device_free_all(card, SNDRV_DEV_CMD_PRE);
      __error:
	kfree(card);
      	return NULL;
#endif

}

/*--------------------------------------------------------------
	Function Description:
		Frees a snd_card_t structure.  This function has been modified
		to call a private free function and assumes a pci structure (frees the pci 
		structure as well.) 
	
	Arguments:
		snd_card_t *pcard - a pointer to the snd_card_t structure to free
	
	Returns:
---------------------------------------------------------------*/

void snd_card_free( snd_card_t *pcard )
{
	if( pcard->pcm )
	{
		snd_pcm_free( pcard->pcm );
	}

	if( pcard->private_free )
	{
		( *pcard->private_free )(pcard);
	}

	kfree( pcard );
}


/*--------------------------------------------------------------
	Function Description:
		Frees the DMA area in the substream.. if one was allocated.
	
	Arguments:
		snd_pcm_substream_t *substream - a pointer to the substream for which to free the
			DMA area
	
	Returns:
---------------------------------------------------------------*/
static void snd_pcm_lib_preallocate_dma_free(snd_pcm_substream_t *substream)
{
	if (substream->dma_buffer.area == NULL)
		return;
#if VX_BUILD_UNUSED		/* add later.. actually do the mem free */
	if (substream->dma_buf_id)
		snd_dma_reserve_buf(&substream->dma_buffer, substream->dma_buf_id);
	else
		snd_dma_free_pages(&substream->dma_buffer);
#else
	free( substream->dma_buffer.area );

#endif
	substream->dma_buffer.area = NULL;
}

/**
 * snd_pcm_lib_preallocate_free - release the preallocated buffer of the specified substream.
 * @substream: the pcm substream instance
 *
 * Releases the pre-allocated buffer of the given substream.
 *
 * Returns zero if successful, or a negative error code on failure.
 */
int snd_pcm_lib_preallocate_free(snd_pcm_substream_t *substream)
{
	snd_pcm_lib_preallocate_dma_free(substream);
#if VX_BUILD_NO_INCLUDE
	if (substream->proc_prealloc_entry) {
		snd_info_unregister(substream->proc_prealloc_entry);
		substream->proc_prealloc_entry = NULL;
	}
#endif
	return 0;
}

/**
 * snd_pcm_lib_preallocate_free_for_all - release all pre-allocated buffers on the pcm
 * @pcm: the pcm instance
 *
 * Releases all the pre-allocated buffers on the given pcm.
 *
 * Returns zero if successful, or a negative error code on failure.
 */
int snd_pcm_lib_preallocate_free_for_all(snd_pcm_t *pcm)
{
	snd_pcm_substream_t *substream;
	int stream;

	for (stream = 0; stream < 2; stream++)
		for (substream = pcm->streams[stream].substream; substream; substream = substream->next)
			snd_pcm_lib_preallocate_free(substream);
	return 0;
}


/**
 * snd_pcm_set_ops - set the PCM operators
 * @pcm: the pcm instance
 * @direction: stream direction, SNDRV_PCM_STREAM_XXX
 * @ops: the operator table
 *
 * Sets the given PCM operators to the pcm instance.
 */
void snd_pcm_set_ops(snd_pcm_t *pcm, int direction, snd_pcm_ops_t *ops)
{
	snd_pcm_str_t *stream = &pcm->streams[direction];
	snd_pcm_substream_t *substream;
	
	for (substream = stream->substream; substream != NULL; substream = substream->next)
		substream->ops = ops;
}



/**
 * snd_pcm_new_stream - create a new PCM stream
 * @pcm: the pcm instance
 * @stream: the stream direction, SNDRV_PCM_STREAM_XXX
 * @substream_count: the number of substreams
 *
 * Creates a new stream for the pcm.
 * The corresponding stream on the pcm must have been empty before
 * calling this, i.e. zero must be given to the argument of
 * snd_pcm_new().
 *
 * Returns zero if successful, or a negative error code on failure.
 */
int snd_pcm_new_stream(snd_pcm_t *pcm, int stream, int substream_count)
{
	int idx, err;
	snd_pcm_str_t *pstr = &pcm->streams[stream];
	snd_pcm_substream_t *substream, *prev;

#if defined(CONFIG_SND_PCM_OSS) || defined(CONFIG_SND_PCM_OSS_MODULE)
	init_MUTEX(&pstr->oss.setup_mutex);
#endif
	pstr->stream = stream;
	pstr->pcm = pcm;
	pstr->substream_count = substream_count;
#if VX_BUILD_NO_INCLUDE
	if (substream_count > 0) {
		err = snd_pcm_stream_proc_init(pstr);
		if (err < 0)
			return err;
	}
	pstr->reg = &snd_pcm_reg[stream];
#endif

	prev = NULL;
	for (idx = 0, prev = NULL; idx < substream_count; idx++) {
		substream = (snd_pcm_substream_t *) kcalloc(1, sizeof(*substream), GFP_KERNEL);
		if (substream == NULL)
			return -ENOMEM;
		substream->pcm = pcm;
		substream->pstr = pstr;
		substream->number = idx;
		substream->stream = stream;
		sprintf(substream->name, "subdevice #%i", idx);
		substream->buffer_bytes_max = UINT_MAX;

		/* note: not sure where this is done in linux.. but it seems like it should work
			to allocate here */
		substream->runtime = (snd_pcm_runtime_t *)kcalloc( 1, sizeof(snd_pcm_runtime_t), 0 );
		if( substream->runtime == NULL )
		{
			kfree( substream );
			return -ENOMEM;
		}

		if (prev == NULL)
			pstr->substream = substream;
		else
			prev->next = substream;

		/* create an empty semaphore to show when the dma period has elapsed */
		err = snd_pcm_substream_proc_init(substream);
		if (err < 0) {
			kfree(substream->runtime);
			kfree(substream);
			return err;
		}

#if VX_BUILD_NO_INCLUDE
		substream->group = &substream->self_group;
		spin_lock_init(&substream->self_group.lock);
		INIT_LIST_HEAD(&substream->self_group.substreams);
		list_add_tail(&substream->link_list, &substream->self_group.substreams);
		spin_lock_init(&substream->timer_lock);
#endif
		prev = substream;
 	}


	return 0;
}

/*--------------------------------------------------------------
	Function Description:
		Allocates memory space of the passed size for DMA access for the
		specified substream and fills in parameters in the structure with
		DMA address/sizes
	
	Arguments:
		snd_pcm_substream_t *substream - a pointer to the substream for which to free the
			DMA area
	
	Returns:
	 	0 on success
		negative on failure
---------------------------------------------------------------*/
static int vx_preallocate_pcm_pages(snd_pcm_substream_t *substream,size_t size )
{
	struct snd_dma_buffer *dmab = &substream->dma_buffer;
	int err;

	snd_assert(size > 0, return -EINVAL);
	
	dmab->bytes = size;
	dmab->addr = (uint32) vx_pci_get_next_dma_mem_space_align( size ); 

	if( dmab->addr == 0 )
	{
		return -1;
	}

	dmab->area = (unsigned char *)dmab->addr;

	/* note: not sure where this is set with linux but seems like it should work to set here */
	substream->runtime->dma_addr = dmab->addr;
	substream->runtime->dma_area = (unsigned char *)dmab->addr;
	substream->runtime->dma_buffer_p = dmab;
	substream->runtime->dma_bytes = size;

	return 0;
}

/**
 * snd_pcm_lib_preallocate_pages - pre-allocation for the given DMA type
 * @substream: the pcm substream instance
 * @type: DMA type (SNDRV_DMA_TYPE_*)
 * @data: DMA type dependant data
 * @size: the requested pre-allocation size in bytes
 * @max: the max. allowed pre-allocation size
 *
 * Do pre-allocation for the given DMA buffer type.
 *
 * When substream->dma_buf_id is set, the function tries to look for
 * the reserved buffer, and the buffer is not freed but reserved at
 * destruction time.  The dma_buf_id must be unique for all systems
 * (in the same DMA buffer type) e.g. using snd_dma_pci_buf_id().
 *
 * Returns zero if successful, or a negative error code on failure.
 */
int snd_pcm_lib_preallocate_pages(snd_pcm_substream_t *substream,
				  int type, struct device *data,
				  size_t size, size_t max)
{
	substream->dma_buffer.dev.type = type;
	substream->dma_buffer.dev.dev = data;
	return snd_pcm_lib_preallocate_pages1(substream, size, max);
}

/*
 * pre-allocate the buffer and create a proc file for the substream
 */

/*--------------------------------------------------------------
	Function Description:
		Allocates DMA buffer space in the passed sustream

	Arguments:
		snd_pcm_substream_t *substream - a pointer to the substream for which to free the
			DMA area
		size_t size (in bytes)

	Returns:
	 	0 on success
		negative on failure
---------------------------------------------------------------*/

static int snd_pcm_lib_preallocate_pages1(snd_pcm_substream_t *substream,
					  size_t size, size_t max)
{
	snd_info_entry_t *entry;

	if (size > 0 && preallocate_dma && substream->number < maximum_substreams)
		vx_preallocate_pcm_pages(substream, size);

	if (substream->dma_buffer.bytes > 0)
		substream->buffer_bytes_max = substream->dma_buffer.bytes;
	substream->dma_max = max;
#if VX_BUILD_NO_INCLUDE
	if ((entry = snd_info_create_card_entry(substream->pcm->card, "prealloc", substream->proc_root)) != NULL) {
		entry->c.text.read_size = 64;
		entry->c.text.read = snd_pcm_lib_preallocate_proc_read;
		entry->c.text.write_size = 64;
		entry->c.text.write = snd_pcm_lib_preallocate_proc_write;
		entry->mode |= S_IWUSR;
		entry->private_data = substream;
		if (snd_info_register(entry) < 0) {
			snd_info_free_entry(entry);
			entry = NULL;
		}
	}
	substream->proc_prealloc_entry = entry;
#endif

	return 0;

}


/**
 * snd_pcm_lib_preallocate_pages_for_all - pre-allocation for continous memory type (all substreams)
 * @substream: the pcm substream instance
 * @type: DMA type (SNDRV_DMA_TYPE_*)
 * @data: DMA type dependant data
 * @size: the requested pre-allocation size in bytes
 * @max: the max. allowed pre-allocation size
 *
 * Do pre-allocation to all substreams of the given pcm for the
 * specified DMA type.
 *
 * Returns zero if successful, or a negative error code on failure.
 */
int snd_pcm_lib_preallocate_pages_for_all(snd_pcm_t *pcm,
					  int type, void *data,
					  size_t size, size_t max)
{
	snd_pcm_substream_t *substream;
	int stream, err;

	for (stream = 0; stream < 2; stream++)
		for (substream = pcm->streams[stream].substream; substream; substream = substream->next)
			if ((err = snd_pcm_lib_preallocate_pages(substream, type, (device *) data, size, max)) < 0)
				return err;
	return 0;
}


/*--------------------------------------------------------------
	Function Description:
		This function was added for use with VxWorks.
		Frees the passed sound device structure and all data

	Arguments:									
		void * snd_device structure to free

	Returns:
---------------------------------------------------------------*/
void vx_snd_dev_free( void *private_data )
{
	snd_device_t *dev = (snd_device_t *)private_data;

	if( dev->ops->dev_free )
	{
		( *dev->ops->dev_free )( dev );
	}
	
	if( dev->card )
	{
		snd_card_free( dev->card );
	}
	
	kfree( dev );

}

/**
 * snd_device_new - create an ALSA device component
 * @card: the card instance
 * @type: the device type, SNDRV_DEV_TYPE_XXX
 * @device_data: the data pointer of this device
 * @ops: the operator table
 *
 * Creates a new device component for the given data pointer.
 * The device will be assigned to the card and managed together
 * by the card.
 *
 * The data pointer plays a role as the identifier, too, so the
 * pointer address must be unique and unchanged.
 *
 * Returns zero if successful, or a negative error code on failure.
 *
 *	Note: this function is modified from the default linux function to 
 *	be passed a pointer to the pci_dev structure.  This allows the
 *	
 */
int vx_snd_device_new(snd_card_t *card, snd_device_type_t type,
		   void *device_data, snd_device_ops_t *ops, pci_dev *pci )
{
	snd_device_t *dev;

	snd_assert(card != NULL && device_data != NULL && ops != NULL , return -ENXIO);
	dev = (snd_device_t *) kcalloc(1, sizeof(*dev), GFP_KERNEL);
	if (dev == NULL)
		return -ENOMEM;
	dev->card = card;
	dev->type = type;
	dev->state = SNDRV_DEV_BUILD;
	dev->device_data = device_data;
	dev->ops = ops; 

	/* these were added for use with vx works.. provide a way to free
		from the PCI device driver level */
	pci->private_data = (void *)dev;
	pci->private_free = vx_snd_dev_free;
	return 0;
}

static int snd_pcm_dev_free(snd_device_t *device)
{
	snd_pcm_t *pcm = (snd_pcm_t *)device->device_data;
	return snd_pcm_free(pcm);
}

static int snd_pcm_dev_register(snd_device_t *device)
{
	return 0;
}

static int snd_pcm_dev_disconnect(snd_device_t *device)
{
	return 0;
}

static int snd_pcm_dev_unregister(snd_device_t *device)
{
	return 0;
}



/**
 * snd_pcm_new - create a new PCM instance
 * @card: the card instance
 * @id: the id string
 * @device: the device index (zero based)
 * @playback_count: the number of substreams for playback
 * @capture_count: the number of substreams for capture
 * @rpcm: the pointer to store the new pcm instance
 *
 * Creates a new PCM instance.
 *
 * The pcm operators have to be set afterwards to the new instance
 * via snd_pcm_set_ops().
 *
 * Returns zero if successful, or a negative error code on failure.
 */
int snd_pcm_new(snd_card_t * card, char *id, int device,
		int playback_count, int capture_count,
	        snd_pcm_t ** rpcm)
{
	snd_pcm_t *pcm;
	int err;

	snd_assert(rpcm != NULL, return -EINVAL);
	*rpcm = NULL;
	snd_assert(card != NULL, return -ENXIO);
	pcm = ( snd_pcm_t *)kcalloc(1, sizeof(*pcm), GFP_KERNEL);
	if (pcm == NULL)
		return -ENOMEM;
	pcm->card = card;
	pcm->device = device;
	if (id) {
		strlcpy(pcm->id, id, sizeof(pcm->id));
	}
	if ((err = snd_pcm_new_stream(pcm, SNDRV_PCM_STREAM_PLAYBACK, playback_count)) < 0) {
		snd_pcm_free(pcm);
		return err;			   
	}
	if ((err = snd_pcm_new_stream(pcm, SNDRV_PCM_STREAM_CAPTURE, capture_count)) < 0) {
		snd_pcm_free(pcm);
		return err;
	}

	init_MUTEX(&pcm->open_mutex);
	init_waitqueue_head(&pcm->open_wait);
/*	if ((err = snd_device_new(card, SNDRV_DEV_PCM, pcm, ops)) < 0) {
		snd_pcm_free(pcm);
		return err;
	}
*/	*rpcm = pcm;
	return 0;
}

/*--------------------------------------------------------------
	This format data table was taken from ALSA code.  Most of these
	formats are currently unused and may or may not actually be supported
---------------------------------------------------------------*/
static pcm_format_data pcm_formats[SNDRV_PCM_FORMAT_LAST+1] = {
	/* [SNDRV_PCM_FORMAT_S8] = */{
		/*.width = */8, 
		/*.phys =*/ 8, 
		/*.le =*/ -1, 
		/*.signd = */1,
		/*.silence = */{},
	},
	/* [SNDRV_PCM_FORMAT_U8] = */{
		/*.width =*/ 8, 
		/*.phys =*/ 8,
		/*.le = */-1, 
		/*.signd =*/ 0,
		/*.silence = */{ 0x80 },
	},
	/* [SNDRV_PCM_FORMAT_S16_LE] = */{
		/*.width =*/ 16,
		/*.phys =*/ 16,
		/*.le = */1,
		/*.signd =*/ 1,
		/*.silence =*/ {},
	},
	/* [SNDRV_PCM_FORMAT_S16_BE] = */{
		/*.width = */16,
		/*.phys =*/ 16,
		/*.le =*/ 0,
		/*.signd =*/ 1,
		/*.silence =*/ {},
	},
	/* [SNDRV_PCM_FORMAT_U16_LE] = */{
		/*.width =*/ 16,
		/*.phys = */16,
		/*.le = */1,
		/*.signd = */0,
		/*.silence = */{ 0x00, 0x80 },
	},
	/* [SNDRV_PCM_FORMAT_U16_BE] = */{
		/*.width = */16,
		/*.phys = */16,
		/*.le = */0,
		/*.signd = */0,
		/*.silence = */{ 0x80, 0x00 },
	},
	/* [SNDRV_PCM_FORMAT_S24_LE] = */{
		/*.width =*/ 24,
		/*.phys =*/ 32,
		/*.le = */1,
		/*.signd = */1,
		/*.silence = */{},
	},
	/* [SNDRV_PCM_FORMAT_S24_BE] = */{
		/*.width = */24,
		/*.phys =*/ 32,
		/*.le = */0,
		/*.signd = */ 1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_U24_LE] = */ {
		/*.width = */ 24,
		/*.phys = */ 32,
		/*.le = */ 1,
		/*.signd = */ 0,
		/*.silence = */ { 0x00, 0x00, 0x80 },
	},
	/* [SNDRV_PCM_FORMAT_U24_BE] = */ {
		/*.width = */ 24,
		/*.phys = */ 32, 
		/*.le = */ 0, 
		/*.signd = */ 0,
		/*.silence = */ { 0x80, 0x00, 0x00 },
	},
	/* [SNDRV_PCM_FORMAT_S32_LE] = */ {
		/*.width = */ 32, 
		/*.phys = */ 32, 
		/*.le = */ 1, 
		/*.signd = */ 1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_S32_BE] = */ {
		/*.width = */ 32, 
		/*.phys = */ 32, 
		/*.le = */ 0, 
		/*.signd = */ 1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_U32_LE] = */ {
		/*.width = */ 32, 
		/*.phys = */ 32, 
		/*.le = */ 1, 
		/*.signd = */ 0,
		/*.silence = */ { 0x00, 0x00, 0x00, 0x80 },
	},
	/* [SNDRV_PCM_FORMAT_U32_BE] = */ {
		/*.width = */ 32, 
		/*.phys = */ 32, 
		/*.le = */ 0, 
		/*.signd = */ 0,
		/*.silence = */ { 0x80, 0x00, 0x00, 0x00 },
	},
	/* [SNDRV_PCM_FORMAT_FLOAT_LE] = */ {
		/*.width = */ 32, 
		/*.phys = */ 32, 
		/*.le = */ 1, 
		/*.signd = */ -1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_FLOAT_BE] = */ {
		/*.width = */ 32, 
		/*.phys = */ 32, 
		/*.le = */ 0, 
		/*.signd = */ -1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_FLOAT64_LE] = */ {
		/*.width = */ 64, 
		/*.phys = */ 64, 
		/*.le = */ 1, 
		/*.signd = */ -1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_FLOAT64_BE] = */ {
		/*.width = */ 64, 
		/*.phys = */ 64, 
		/*.le = */ 0, 
		/*.signd = */ -1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_IEC958_SUBFRAME_LE] = */ {
		/*.width = */ 32, 
		/*.phys = */ 32, 
		/*.le = */ 1, 
		/*.signd = */ -1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_IEC958_SUBFRAME_BE] = */ {
		/*.width = */ 32, 
		/*.phys = */ 32, 
		/*.le = */ 0, 
		/*.signd = */ -1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_MU_LAW] = */ {
		/*.width = */ 8, 
		/*.phys = */ 8, 
		/*.le = */ -1, 
		/*.signd = */ -1,
		/*.silence = */ { 0x7f },
	},
	/* [SNDRV_PCM_FORMAT_A_LAW] = */ {
		/*.width = */ 8, 
		/*.phys = */ 8, 
		/*.le = */ -1, 
		/*.signd = */ -1,
		/*.silence = */ { 0x55 },
	},
	/* [SNDRV_PCM_FORMAT_IMA_ADPCM] = */ {
		/*.width = */ 4, 
		/*.phys = */ 4, 
		/*.le = */ -1, 
		/*.signd = */ -1,
		/*.silence = */ {},
	},
	/* FIXME: the following three formats are not defined properly yet */
	/* [SNDRV_PCM_FORMAT_MPEG] = */ {
		/*.width = */ 0, 
		/*.phys = */ 0, 
		/*.le = */ -1, 
		/*.signd = */ -1,
	},
	/* [SNDRV_PCM_FORMAT_GSM] = */ {
		/*.width = */ 0, 
		/*.phys = */ 0, 
		/*.le = */ -1, 
		/*.signd = */ -1,
	},
	/* [SNDRV_PCM_FORMAT_SPECIAL] = */ {
		/*.width = */ 0, 
		/*.phys = */ 0, 
		/*.le = */ -1, 
		/*.signd = */ -1,
	},
	/* [SNDRV_PCM_FORMAT_S24_3LE] = */ {
		/*.width = */ 24, 
		/*.phys = */ 24, 
		/*.le = */ 1, 
		/*.signd = */ 1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_S24_3BE] = */ {
		/*.width = */ 24, 
		/*.phys = */ 24, 
		/*.le = */ 0, 
		/*.signd = */ 1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_U24_3LE] = */ {
		/*.width = */ 24, 
		/*.phys = */ 24, 
		/*.le = */ 1, 
		/*.signd = */ 0,
		/*.silence = */ { 0x00, 0x00, 0x80 },
	},
	/* [SNDRV_PCM_FORMAT_U24_3BE] = */ {
		/*.width = */ 24, 
		/*.phys = */ 24, 
		/*.le = */ 0, 
		/*.signd = */ 0,
		/*.silence = */ { 0x80, 0x00, 0x00 },
	},
	/* [SNDRV_PCM_FORMAT_S20_3LE] = */ {
		/*.width = */ 20, 
		/*.phys = */ 24, 
		/*.le = */ 1, 
		/*.signd = */ 1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_S20_3BE] = */ {
		/*.width = */ 20, 
		/*.phys = */ 24, 
		/*.le = */ 0, 
		/*.signd = */ 1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_U20_3LE] = */ {
		/*.width = */ 20, 
		/*.phys = */ 24, 
		/*.le = */ 1, 
		/*.signd = */ 0,
		/*.silence = */ { 0x00, 0x00, 0x08 },
	},
	/* [SNDRV_PCM_FORMAT_U20_3BE] = */ {
		/*.width = */ 20, 
		/*.phys = */ 24, 
		/*.le = */ 0, 
		/*.signd = */ 0,
		/*.silence = */ { 0x08, 0x00, 0x00 },
	},
	/* [SNDRV_PCM_FORMAT_S18_3LE] = */ {
		/*.width = */ 18, 
		/*.phys = */ 24, 
		/*.le = */ 1, 
		/*.signd = */ 1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_S18_3BE] = */ {
		/*.width = */ 18, 
		/*.phys = */ 24, 
		/*.le = */ 0, 
		/*.signd = */ 1,
		/*.silence = */ {},
	},
	/* [SNDRV_PCM_FORMAT_U18_3LE] = */ {
		/*.width = */ 18, 
		/*.phys = */ 24, 
		/*.le = */ 1, 
		/*.signd = */ 0,
		/*.silence = */ { 0x00, 0x00, 0x02 },
	},
	/* [SNDRV_PCM_FORMAT_U18_3BE] = */ {
		/*.width = */ 18, 
		/*.phys = */ 24, 
		/*.le = */ 0, 
		/*.signd = */ 0,
		/*.silence = */ { 0x02, 0x00, 0x00 },
	},
};

   
   /**
 * snd_pcm_format_width - return the bit-width of the format
 * @format: the format to check
 *
 * Returns the bit-width of the format, or a negative error code
 * if unknown format.
 */
int snd_pcm_format_width(snd_pcm_format_t format)
{
	int val;
	if (format < 0 || format > SNDRV_PCM_FORMAT_LAST)
		return -EINVAL;
	if ((val = pcm_formats[format].width) == 0)
		return -EINVAL;
	return val;
}

/**
 * snd_pcm_format_signed - Check the PCM format is signed linear
 * @format: the format to check
 *
 * Returns 1 if the given PCM format is signed linear, 0 if unsigned
 * linear, and a negative error code for non-linear formats.
 */
int snd_pcm_format_signed(snd_pcm_format_t format)
{
	int val;
	if (format < 0 || format > SNDRV_PCM_FORMAT_LAST)
		return -EINVAL;
	if ((val = pcm_formats[format].signd) < 0)
		return -EINVAL;
	return val;
}

/**
 * snd_pcm_format_unsigned - Check the PCM format is unsigned linear
 * @format: the format to check
 *
 * Returns 1 if the given PCM format is unsigned linear, 0 if signed
 * linear, and a negative error code for non-linear formats.
 */
int snd_pcm_format_unsigned(snd_pcm_format_t format)
{
	int val;

	val = snd_pcm_format_signed(format);
	if (val < 0)
		return val;
	return !val;
}

/**
 * snd_pcm_free_stream - Free the passed pcm stream and all substreams
 * @pstr: the stream to free
 *
 */
static void snd_pcm_free_stream(snd_pcm_str_t * pstr)
{
	snd_pcm_substream_t *substream, *substream_next;
#if defined(CONFIG_SND_PCM_OSS) || defined(CONFIG_SND_PCM_OSS_MODULE)
	snd_pcm_oss_setup_t *setup, *setupn;
#endif
	substream = pstr->substream;
	while (substream) {
		substream_next = substream->next;
		snd_pcm_substream_proc_done(substream);
		kfree(substream);
		substream = substream_next;
	}
	snd_pcm_stream_proc_done(pstr);

#if defined(CONFIG_SND_PCM_OSS) || defined(CONFIG_SND_PCM_OSS_MODULE)
	for (setup = pstr->oss.setup_list; setup; setup = setupn) {
		setupn = setup->next;
		kfree(setup->task_name);
		kfree(setup);
	}
#endif
}

/**
 * snd_pcm_free - Free the passed pcm structure and all streams/substreams
 * @pcm: the pcm structure to free
  *
 */
static int snd_pcm_free(snd_pcm_t *pcm)
{
	snd_assert(pcm != NULL, return -ENXIO);
	if (pcm->private_free)
		pcm->private_free(pcm);
	snd_pcm_lib_preallocate_free_for_all(pcm);
	snd_pcm_free_stream(&pcm->streams[SNDRV_PCM_STREAM_PLAYBACK]);
	snd_pcm_free_stream(&pcm->streams[SNDRV_PCM_STREAM_CAPTURE]);
	kfree(pcm);
	return 0;
}


size_t frames_to_bytes(snd_pcm_runtime_t *runtime, snd_pcm_sframes_t size)
{
	return size * runtime->frame_bits / 8;
}

size_t snd_pcm_lib_buffer_bytes(snd_pcm_substream_t *substream)
{
	snd_pcm_runtime_t *runtime = substream->runtime;
	return frames_to_bytes(runtime, runtime->buffer_size);
}

inline size_t snd_pcm_lib_period_bytes(snd_pcm_substream_t *substream)
{
	snd_pcm_runtime_t *runtime = substream->runtime;
	return frames_to_bytes(runtime, runtime->period_size);
}

/**
 * vx_snd_pcm_substream_proc_done - Kill the task for the passed substream
 * @substream: the substream structure to reference
  *
 */
static int vx_snd_pcm_substream_proc_done( snd_pcm_substream_t *substream )
{
	semDelete( substream->sem_period_elapsed ); 
	if( substream->substr_taskID )
	{
		taskDelete( substream->substr_taskID );
	}
	kfree( substream->runtime );
	return 0;
}

/**
 * vx_snd_pcm_substream_proc_init - Initalize a task for the passed substream
 * @substream: the substream structure to initialize
  *
 */
static int vx_snd_pcm_substream_proc_init( snd_pcm_substream_t *substream )
{
	snd_card_t *card;
	char name[32];
	card = substream->pcm->card;

	sprintf(substream->name, "pcm%i%c_sub%i", substream->pcm->device, (substream->pstr->stream == SNDRV_PCM_STREAM_PLAYBACK ? 'p' : 'c'), substream->number );

	substream->sem_period_elapsed = semBCreate( SEM_Q_PRIORITY, SEM_EMPTY ); 

	if( substream->sem_period_elapsed == NULL )
	{
		return -1;
	}

}

/**
 * snd_pcm_set_runtime_buffer - Initalize the runtime area of a substream with the new DMA buffer data
 * @substream: the substream structure to initialize
 * @bufp: the dma buffer data
 */
static inline void snd_pcm_set_runtime_buffer(snd_pcm_substream_t *substream,
					      struct snd_dma_buffer *bufp)
{
	snd_pcm_runtime_t *runtime = substream->runtime;
	if (bufp) {
		runtime->dma_buffer_p = bufp;
		runtime->dma_area = bufp->area;
		runtime->dma_addr = bufp->addr;
		runtime->dma_bytes = bufp->bytes;
	} else {
		runtime->dma_buffer_p = NULL;
		runtime->dma_area = NULL;
		runtime->dma_addr = 0;
		runtime->dma_bytes = 0;
	}
}


/**
 * vx_snd_setup_runtime - Initialize the substream runtime data with defaults.
 *  	based on the passed hardware structure.  
 *		This function may need to be tweaked as new cards are added.
 *
 * @substream: the substream structure to initialize
 * @hw: the snd_pcm_hardware_t structure for this device
 */
void vx_snd_setup_runtime( snd_pcm_substream_t *substream , snd_pcm_hardware_t *hw )
{
	snd_pcm_runtime_t *runtime = substream->runtime;
	runtime->rate =  48000;
	runtime->rate_num = 768000; 
	runtime->rate_den =  runtime->rate_num/runtime->rate;
	runtime->channels = hw->channels_min;
	runtime->format	= SNDRV_PCM_FORMAT_U8;	   
/*	runtime->dma_bytes = hw->buffer_bytes_max; 
	substream->dma_buffer.bytes = hw->buffer_bytes_max; */
	runtime->frame_bits = 8;
	runtime->buffer_size = hw->buffer_bytes_max;
	runtime->period_size = hw->buffer_bytes_max/2;
	runtime->periods = 2;
	/* clear the interrupt count variable */
	substream->interrupt_cnt = 0;
	substream->private_data = substream->pcm->private_data;
	
}

/**
 * vx_snd_pcm_period_elapsed - Called when the period has elapsed
 *	for the passed substream (called from interrupt).
 *  Gives the semaphore and increments counters
 *
 * @substream: the substream structure for which the period has elapsed
 */
void vx_snd_pcm_period_elapsed( snd_pcm_substream_t *substream )
{
	assert( semGive( substream->sem_period_elapsed ) == OK ); 
	substream->interrupt_cnt++;	
	snd_interrupt++;
}

/**
 * vx_snd_card_register - Registers a pcm structure to a given sound card
 *	Greatly simplified from how this works with Linux for use with VxWorks
 *
 * @card: a pointer to the card to register
 * &pcm: a pointer to the PCM structure to register to this card
 */
int vx_snd_card_register( snd_card_t *card, snd_pcm_t *pcm )
{
	/* a simpler way to register card to PCM than is done w/ linux
		assumes all cards will use PCM functions */
	card->pcm = pcm;
	return 0;
}


/**
 * vx_snd_start_driver - 
	Called from the PCI device scan when a sound card is found on the bus after
	the sound card has been initialized with the probe() function.

	specify this function in your pci_driver table to use the VxSound driver.

 * @pci: a pointer to the pci_dev structure for this card
 */
int vx_snd_start_driver( pci_dev *pci )
{
	snd_card_t *card;
	snd_pcm_str_t *playbackStr;
	snd_pcm_str_t *captureStr;

	pGlobPCIDev	= pci;

	/* get the sound card info */
	card = (snd_card_t *)pci->dev.driver_data;

	/* set the global sound card pointer for reference/debug */
	psndCard = card;
	
	playbackStr = &card->pcm->streams[SNDRV_PCM_STREAM_PLAYBACK];
	captureStr = &card->pcm->streams[SNDRV_PCM_STREAM_CAPTURE];

	/* note: currently only using one stream... if multiple streams 
		are added, will need to implement spinlocks so we can guarantee
		hardware accesses will not be interrupted */	
	if( playbackStr )
	{
		gplayback = playbackStr->substream;
		playbackStr->substream->private_data = playbackStr->substream->pcm->private_data;
		printf("opening playback\n");
		playbackStr->substream->ops->open( playbackStr->substream );
		vx_snd_setup_runtime( playbackStr->substream, &playbackStr->substream->runtime->hw );
		playbackStr->substream->substr_taskID = taskSpawn("Playback", 10, 0, (1024*8), (FUNCPTR) sndAp.playback.pfunc, (int)playbackStr->substream,0,0,0,0,0,0,0,0,0);
	}
	
	return 0;
}