/****************************************************************
*
* MODULE:		vx_tone_ap.cpp
*
* DESCRIPTION:  Definitions of functions used for the tone_ap application
*
* ORIGINAL AUTHOR: 	Dan Walkes
*					
* UPDATED BY:		
* 
* CREATED:		Oct, 2005
* MODIFIED:		
* 
* NOTES:
*
*
*
* REVISION HISTORY AND NOTES:
*
* Date			Update
* ---------------------------------------------------------------------
* Oct 1, 2005	Created.
*
* REFERENCES:
*
* 1) "vxWALSA Sound Driver" document included with this release.
*
****************************************************************/



#define TONE_PLAYBACK_PRIORITY	10
void toneApPlaybackTaskInit( snd_pcm_substream_t *substream );
