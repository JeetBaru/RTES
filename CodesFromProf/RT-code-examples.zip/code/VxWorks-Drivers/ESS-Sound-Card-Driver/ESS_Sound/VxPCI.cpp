/****************************************************************
*
* MODULE:		VxPCI.cpp
*
* DESCRIPTION:	Functions used to install PCI linux-compatable drivers on a VxWorks 
*				system
*				
* ORIGINAL AUTHOR: 	Dan Walkes - with several structure/data definitions
*						and code referenced from linux source tree
*					
* UPDATED BY:		
* 
* CREATED:		Oct, 2005
* MODIFIED:		
* 
* NOTES:
*
*	Many assumptions were made in this file as of the first release to simplify
*	the code, the most important of which are listed below:
*
*		1) Interrupt routing and memory access for North/Soutbridge is initialized
*			by the BIOS (or some other utility)
*		2) PCI_SYSTEM_START_MEM_ALLOC_SPACE and  PCI_SYSTEM_START_IO_ALLOC_SPACE are
*			set to ranges of free PCI memory and IO spaces with sizes large enough for
*			all possible installed drivers.
*
* CODE USAGE:
*	Below is a basic overview of how to use this module.  For more information please
*	see the documents listed in the "Reference" section.
*
*	Starting/Stopping Drivers:
*		vx_pci_start - Starts drivers for all installed PCI cards.  Make sure that a pointer to
*						your pci_driver	table is included in the pci_DrvTable structure
*
*		vx_pci_stop - Stops and un-installs all currently installed PCI cards and frees
*						all resources. 
*
*
*	Debug Functions:
*		d_vxpci_display - Displays information about all found devices
*
*		d_vxpci_get - returns a register value for a specific PCI device
*
*		d_vxpci_set - sets a register value for a specific PCI device
*
*
* REVISION HISTORY AND NOTES:
*
* Date			Update
* ---------------------------------------------------------------------
* Oct 1, 2005	Created.
*
* REFERENCES:
*
* 1) "vxWALSA Sound Driver" document included with this release.
*
****************************************************************/


/* Vxworks -linux includes */
#include "VxTypes.h"
#include "VxPCI.h"
#include "VxSound.h"
#include "es1938.h"




/* pcPentium BSP includes */
#include "sysLib.h"

/*--------------------------------------------------------------
	#defines
----------------------------------------------------------------*/

/* set this to the start of your MMIO space */
#define 	PCI_SYSTEM_START_MEM_ALLOC_SPACE	 0x04000000
#define 	PCI_SYSTEM_START_IO_ALLOC_SPACE		 0xE000


/*--------------------------------------------------------------
	Global Variables
----------------------------------------------------------------*/

unsigned long  	pci_memAllocRegionStart = PCI_SYSTEM_START_MEM_ALLOC_SPACE;
unsigned long 	pci_IOAllocRegionStart = PCI_SYSTEM_START_IO_ALLOC_SPACE;

/* null terminated table including all pci drivers 
	Place a pointer to your pci_driver table in the null-terminated
	list to include your driver.
*/
static const pci_driver *pci_DrvTable[] =
{
	&ES1938_driver,
	NULL,
};

/* currently only bus 0 is supported.. this is the default structure */
static const pci_bus pci_Bus0Struct ={
/*	.number = 0;
	.bus_id = "Bus ID 0";  */
	0,
	{ "Bus ID 0" }
};
	
/* this global holds a pointer to the pci dev linked list */
static pci_dev	*pci_pListHeadDev = 0;

/*--------------------------------------------------------------
	Function Prototypes
----------------------------------------------------------------*/
static int pci_baseAddressRegisterSizeOfDecodeSpace(int returnval);
static int vx_pci_probe_devices( const pci_driver *pPCIDrvTable[], pci_dev *pci );
int d_vxpci_get( int req_device, int reg,  unsigned char numbytes );


/*--------------------------------------------------------------
	Function Description:
		Sets up the passed resource structure based on the value
		read back from the Base Address Register.  Allocates memory
		or I/O space based on global #defines and variables
	
	Arguments:
		resource *pres - a pointer to the resource to initialize
		unsigned int barReadback - the value read from the Base Address Register
	
	Returns:
		0 (success)		
---------------------------------------------------------------*/
static int vx_pci_set_resource(resource *pres, unsigned int barReadback )
{

	if( !BAR_IS_IMPLEMENTED( barReadback ) )
	{
		pres->start = 0;
		pres->end = 0;
		pres->flags = IORESOURCE_DISABLED;
	}
	else 
	{
		if(BAR_IS_MEM_ADDRESS_DECODER( barReadback ) )
		{
			pres->flags = IORESOURCE_MEM;
			pres->start = pci_memAllocRegionStart;
			pres->end = pres->start + pci_baseAddressRegisterSizeOfDecodeSpace( barReadback )-1;
			pci_memAllocRegionStart =  pres->end +1;
			PCI_DEBUG_PRINT("Mem Resource Start %x End %x\n",pres->start,pres->end );
		}
		if( BAR_IS_IO_ADDRESS_DECODER( barReadback ) )
		{
		 	pres->flags = IORESOURCE_IO;
			pres->start = pci_IOAllocRegionStart;
			pres->end = pres->start + pci_baseAddressRegisterSizeOfDecodeSpace( barReadback )-1;
			pci_IOAllocRegionStart =  pres->end +1;
			PCI_DEBUG_PRINT("I/O Resource Start %x End %x\n",pres->start,pres->end );
		}
	}
			
	return SUCCESS_vx;
}

/* -------------------------------------------------------

	Function : 	 pci_enable_device_bars_vx

	Arguments:	
		struct pci_dev *pci - a pointer to the pci device structure

	Returns:
		SUCCESS_vx on success
		negative value representing error type on failure

	Note:
		Source for this function was influenced by btvid_controller_config
*/
int pci_enable_device_bars_vx(pci_dev *pci)
{
	int pciBusNo = pci->bus->number;
	int pciDevNo = PCI_SLOT(pci->devfn);
	int pciFuncNo = PCI_FUNC(pci->devfn);
	int ix,barreg=0, err;
	unsigned int testval;

	pci->irq = 0;

	/* Get the programmed interrupt value */
 	pciConfigInByte(pciBusNo, pciDevNo, pciFuncNo,
		    PCI_CFG_DEV_INT_LINE, (uint8*)&pci->irq);

	/* Disable the device */
//	pciConfigOutWord (pciBusNo, pciDevNo, pciFuncNo, PCI_CFG_COMMAND, 0);


	for (ix = PCI_CFG_BASE_ADDRESS_0; ix <= PCI_CFG_BASE_ADDRESS_5; ix+=4, barreg++)
	{
		pciConfigInLong(pciBusNo, pciDevNo, pciFuncNo, ix, &testval);

		PCI_DEBUG_PRINT("BAR %d testval=0x%x before writing 0xffffffff's \n", barreg, testval);

		/* Write all f's and read back value */

		pciConfigOutLong(pciBusNo, pciDevNo, pciFuncNo, ix, 0xffffffff);
		pciConfigInLong(pciBusNo, pciDevNo, pciFuncNo, ix, &testval);

		/* setup resources for this register */
		if( ( err = vx_pci_set_resource(&pci->resource[barreg],testval) ) < 0 )
		{

			return err;
		}
	
		/* write the starting address into the BAR */
		pci_write_config_dword( pci, ix, pci->resource[barreg].start );	

		if(!BAR_IS_IMPLEMENTED(testval)) {
			PCI_DEBUG_PRINT("BAR %d not implemented\n", ((ix/4)-4));
		} else {
		if(BAR_IS_MEM_ADDRESS_DECODER(testval)) {
			PCI_DEBUG_PRINT("BAR %d is a Memory Address Decoder\n", ((ix/4)-4));
			
			if(BAR_IS_32_BIT_DECODER(testval))
				PCI_DEBUG_PRINT( "BAR %d is a 32-Bit Decoder \n", ((ix/4)-4) );
			else if(BAR_IS_64_BIT_DECODER(testval))	
				PCI_DEBUG_PRINT( "BAR %d is a 64-Bit Decoder \n", ((ix/4)-4) );
			else
				PCI_DEBUG_PRINT( "BAR %d memory width is undefined \n", ((ix/4)-4) );

			if(BAR_IS_PREFETCHABLE(testval))
				PCI_DEBUG_PRINT( "BAR %d address space is prefetachable \n", ((ix/4)-4));
			
		} else if(BAR_IS_IO_ADDRESS_DECODER(testval)) {
			PCI_DEBUG_PRINT("BAR %d is an IO Address Decoder \n", ((ix/4)-4));
		} else {
			PCI_DEBUG_PRINT("BAR %d is niether an IO Address Decoder or an Memory Address Decoder (error probably) \n", ((ix/4)-4));	
		}
		
	printf("BAR %d decodes a space %i bytes big\n", ((ix/4)-4), 
		pci_baseAddressRegisterSizeOfDecodeSpace(testval));
	}

	PCI_DEBUG_PRINT("\n\n");
	}


}

/* -------------------------------------------------------
	Function : 	 pci_baseAddressRegisterSizeOfDecodeSpace

	Note:
	This function takes the entire 32 bit readback register value including bits 
	[3:0] and returns the position starting from 0 of the first bit not 0

	Taken from btvid.c function with the same name
*/

static int pci_baseAddressRegisterSizeOfDecodeSpace(int returnval) 
{

	int tmp = 0;
	int bitpos = 0;
	int i = 0;
	
	tmp = returnval;
       	tmp &= 0xFFFFFFF0;
	
	for(i = 0; i < 32; i++) {
		if(tmp & 0x1) {
			return (int)pow(2,bitpos);
		} else {
		
			bitpos++;
			tmp >>= 1;	
		}
	}
		
}

/* -------------------------------------------------------
	Not yet implemented

*/

int pci_disable_device_vx( struct pci_dev *pci )
{
	return SUCCESS_vx;
}


/* -------------------------------------------------------
	Function : 	 pci_set_master

*/

void pci_set_master(struct pci_dev *dev)
{
	u16 cmd;

	pci_read_config_word(dev, PCI_COMMAND_OFFS, &cmd);
	if (! (cmd & PCI_COMMAND_MASTER)) {
/*		pr_debug("PCI: Enabling bus mastering for device %s\n", pci_name(dev)); */
		cmd |= PCI_COMMAND_MASTER;
		pci_write_config_word(dev, PCI_COMMAND_OFFS, cmd);
	}
	dev->is_busmaster = 1;
	pcibios_set_master(dev);
}



/* -------------------------------------------------------
	Function : 	 vx_pci_alloc_new_pci_dev

	Allocates a new pci dev for the specified bus (currently only bus 0 is supported)

	Returns a pointer to the allocated structure
*/

static pci_dev *vx_pci_alloc_new_pci_dev( int busNo )
{
	/* for now, do nothing with bus number */
	pci_dev *pDev;
	pci_dev *pDevPrev=0;

	pDev = pci_pListHeadDev;

	while( pDev )
	{
		pDevPrev = pDev;
		pDev = (pci_dev *)pDev->global_list.next;
	}

	pDev = (pci_dev *) malloc( sizeof(pci_dev) );	/* malloc a new pci device structure */

	if( pDev == NULL )
	{
		return pDev;
	}

	memset(pDev,0,sizeof(pci_dev));

	if( pDevPrev )
	{
		pDev->global_list.prev = (list_head *)pDevPrev;
		pDevPrev->global_list.next = (list_head *)pDev;
	}
	else
	{
		pci_pListHeadDev = pDev;
	}

	return pDev;
}

/* --------------------------------------------------
	Removes a pci_dev structure from the linked list.
	Note: does not currently handle PCI device memory resource de-allocation.. 
*/	
void vx_pci_remove_pci_dev( pci_dev *pDev )
{

	if( pDev->global_list.prev )
	{
		((pci_dev *)pDev->global_list.prev)->global_list.next = pDev->global_list.next;
	}
	else
	{
		pci_pListHeadDev = (pci_dev *)pDev->global_list.next;
		((pci_dev *)pDev->global_list.next)->global_list.prev = 0;
	}
	 
	if(	pDev->private_free )
	{
		(*pDev->private_free)(	pDev->private_data );
	}

	free( pDev );	/* de-allocate memory */
}

/* -------------------------------------------------------
	Function : 	 vx_pci_find_pci_dev

	Finds the pci_dev structure for a device with the given
	bus number, device number and function number

	Returns a pointer to the found structure
*/	
static pci_dev *vx_pci_find_pci_dev( int busNo, int DevNo, int FuncNo )
{
	pci_dev *pDev;
	 
	pDev = pci_pListHeadDev;

	while( pDev )
	{
		if( pDev->bus->number == busNo &&
			PCI_FUNC(pDev->devfn) == FuncNo &&
			PCI_SLOT(pDev->devfn) == DevNo )
		{
			return pDev;
		}

		pDev = (pci_dev *)pDev->global_list.next;
	}

	return NULL;	/* didn't find this device */

}	

/* -------------------------------------------------------
	Function : 	 vx_pci_probe_all_recognized_devices

	Looks for devices on the bus and attempts to match them
	with devices in the PCI driver table
*/	
static int vx_pci_probe_all_recognized_devices ( void )
{

	pci_dev *pDev;
	 
	pDev = pci_pListHeadDev;

	while( pDev )
	{
		if(	vx_pci_probe_devices( pci_DrvTable, pDev ) < 0 )
		{
			PCI_DEBUG_PRINT( "Error probing pci device\n");
			return ERR0R_GEN_FAIL_vx;
		}
	
		pDev = (pci_dev *)pDev->global_list.next;
	}

	return SUCCESS_vx;

}

/* -------------------------------------------------------
	Function : 	 vx_pci_scan_bus

	Scans the PCI bus to find devices.
	Allocates a pci_dev structure for each device found and
	places in the linked list	
*/
int vx_pci_scan_bus( void )
{
	int deviceNo;
	int devices;
	ushort_t vendorId;
	ushort_t deviceId;
	union
	{
	    int classCode;
    	unsigned char array[4];
	} u;
	int busNo = 0;
	pci_dev *pDev;

	if (pciConfigLibInit (PCI_MECHANISM_1, 0xCF8, 0xCFC, 0) != OK)
	{
    	PCI_DEBUG_PRINT("PCI lib config error\n");
		return (ERR0R_GEN_FAIL_vx);
	}
  
	devices = 0x1f;
    
	PCI_DEBUG_PRINT("Bus #, Device#, vendorID, deviceID, u.classCode\n");
 
	for (deviceNo=0; deviceNo < devices; deviceNo++)
	{
	    pciConfigInWord (busNo, deviceNo, 0, PCI_CFG_VENDOR_ID, &vendorId);
    	pciConfigInWord (busNo, deviceNo, 0, PCI_CFG_DEVICE_ID, &deviceId);
	    pciConfigInByte (busNo, deviceNo, 0, PCI_CFG_PROGRAMMING_IF,
    	         &u.array[3]);
	    pciConfigInByte (busNo, deviceNo, 0, PCI_CFG_SUBCLASS, &u.array[2]);
    	pciConfigInByte (busNo, deviceNo, 0, PCI_CFG_CLASS, &u.array[1]);
	    u.array[0] = 0;
	
    	if (vendorId != 0xffff)
		{	 
			PCI_DEBUG_PRINT ("%.8x  %.8x  %.8x  %.8x  %.8x  %.8x\n",
	                busNo, deviceNo, 0, vendorId, deviceId, u.classCode);
		
			if( ( pDev = vx_pci_find_pci_dev( busNo, deviceNo, 0 ) ) != NULL )
			{
				PCI_DEBUG_PRINT( "device already found on this bus, device #\n" );
			}
			else
			{     		
				if( (pDev = vx_pci_alloc_new_pci_dev( busNo )) == NULL )
				{
					return ERR0R_GEN_FAIL_vx;
				}
			}


			pDev->bus = (pci_bus *) &pci_Bus0Struct;
			pDev->device = deviceId;
			pDev->devfn = PCI_DEVFN( deviceNo, 0 );
			pDev->vendor = vendorId;

		}
		/* fill in the PCI dev structure with the values found on the bus */

	}


	return (SUCCESS_vx);
}


/* -------------------------------------------------------
	Function : 	 vx_pci_probe_id_table_match

	Looks for a match in the pci_device_id null termated table
	specified by a driver funtion.  If a match is found, returns a pointer
	to the table ID entry.
*/
pci_device_id *vx_pci_probe_id_table_match(const pci_device_id *pTableStart, pci_dev *pci )
{
	pci_device_id *pTableEntry;

	pTableEntry = (pci_device_id *)pTableStart;

	while( pTableEntry->device )	/* look for null-terminated end of table */
	{
		if( pTableEntry->device == pci->device &&
			pTableEntry->vendor == pci->vendor )
		{
			return pTableEntry;
		}

		pTableEntry++;	/* go to the next table entry */
	}

	/* no match found in the table */
	return NULL;

}		 

/* -------------------------------------------------------
	Function : 	 vx_pci_probe_devices

	Attempts to match a pci_dev structure with and entry in the 
	passed driver table.  If a match is found, resources are allocated,
	the probe function and driver functions are called.    
*/
static int vx_pci_probe_devices( const pci_driver *pPCIDrvTable[], pci_dev *pci )
{
	pci_driver *pDriverTable;
	pci_device_id *pIDTableEntry;
	int err;
	int index=0;

	pDriverTable = (pci_driver *)pPCIDrvTable[index];	/* get the address of the first table */

	while( pDriverTable )
	{	
		if( ( pIDTableEntry = vx_pci_probe_id_table_match( pDriverTable->id_table, pci ) ) != 0 )
		{
			PCI_DEBUG_PRINT( "Found Matching PCI ID Device %s:\n", pDriverTable->name );

			strcpy( pci->pretty_name, pDriverTable->name );

			if( ( err = pci_enable_device_bars_vx( pci ) < 0 ) ) /* enable bar's for this device */
			{
				PCI_DEBUG_PRINT( "Error %d when configuring pci BAR\n", err );
				return ERR0R_GEN_FAIL_vx;
			}
							
			if( ( err = ( *pDriverTable->probe )( pci, pIDTableEntry ) ) < 0 )
			{
				PCI_DEBUG_PRINT( "Error: probe failed for device with error %d\n", err );
				return ERR0R_GEN_FAIL_vx;

			}
			if ( ( err = ( ( *pDriverTable->vx_start_driver ) ( pci ) )) < 0 )
			{
				PCI_DEBUG_PRINT( "Error: driver start failed for device with error %d\n", err );
				return ERR0R_GEN_FAIL_vx;
			}			  
		}
		pDriverTable =  (pci_driver *)pPCIDrvTable[++index];	// set the next probe table entry
	}

	return SUCCESS_vx;
}
				

/* -------------------------------------------------------
	Function : 	 vx_pci_start

	A command-line function which can be used to start all PCI drivers
*/
			
int vx_pci_start( void )
{
	int err;

	if( ( err = vx_pci_scan_bus() ) < 0 )
	{
		return err;
	}

	return	vx_pci_probe_all_recognized_devices();
}


/* -------------------------------------------------------
	Function : 	 vx_pci_stop

	A command-line function which can be used to stop all PCI drivers
*/

void vx_pci_stop( void )
{
	pci_dev *pDev;
	int	count = 0;		   

	/* re-start the memory allocation from the start of alloc space */
	pci_memAllocRegionStart = PCI_SYSTEM_START_MEM_ALLOC_SPACE;
 	pci_IOAllocRegionStart = PCI_SYSTEM_START_IO_ALLOC_SPACE;

	pDev = pci_pListHeadDev;

	while( pDev )
	{
		vx_pci_remove_pci_dev( pDev );
		pDev = pci_pListHeadDev;
		count++;
	};

	PCI_DEBUG_PRINT( "vx_pci_remove_all_devices: %d devices removed\n",count );
}


/* -------------------------------------------------------
	Function : 	 vx_pci_free_irq

	A function to disconnect the PCI IRQ number passed.  Used
	for un-installing drivers
*/
int vx_pci_free_irq( int irqnum, VOIDFUNCPTR funcptr )
{
	printf("Freeing IRQ %d",irqnum );
	sysIntDisablePIC( irqnum );
	pciIntDisconnect( ( INUM_TO_IVEC ( irqnum+INT_NUM_IRQ0 ) ), funcptr );
	return 0;
}

/* -------------------------------------------------------
	Function : 	 vx_pci_request_irq

	A function to request a PCI IRQ based on the number passed and
	connect it to the passed function.  The param value will be passed
	to the function when the interrupt is serviced.

	Call vx_pci_free_irq to free this IRQ when no longer in use
*/
int vx_pci_request_irq( int irqnum, VOIDFUNCPTR funcptr,  int param )
{
	printf( "Hooking interrupt %d with param 0x%x\n",irqnum,param );

	if( pciIntConnect(( INUM_TO_IVEC ( irqnum+INT_NUM_IRQ0 ) ), funcptr, param ) == OK )	
	{
		printf( "Enabling interrupt %d\n",irqnum );
		if( sysIntEnablePIC(irqnum) == OK )
		{
			return 0;
		}
	}
	return -1;
}
		
/* -------------------------------------------------------
	Function : 	 vx_pci_get_next_dma_mem_space_align

	Allocates a memory space (aligned buffer) of the passed size
	for PCI DMA purposes.  
	
	Free this buffer with free() when no longer in use
*/
void *vx_pci_get_next_dma_mem_space_align( uint32 size )
{
	return valloc( size ); 
}

/* -------------------------------------------------------
	Function : 	 d_vxpci_display

	A debug function which prints out data describing which devices were
	found on the bus
*/
void d_vxpci_display( void )
{
	pci_dev *pDev;
	int device=0;

	pDev = pci_pListHeadDev;
	
	printf("PCI Device List\n#\tName\n");

	while( pDev )
	{
		printf( "%d:", device );

		if( strlen(pDev->pretty_name) )
		{
			printf( " %s\n", pDev->pretty_name );
		}
		else
		{
			printf( " Unknown \n" );
		}

		pDev = (pci_dev *)pDev->global_list.next;
		device++;

	}

	if( device == 0 )
	{
		printf("No devices found\n");
	}

}


/* -------------------------------------------------------
	Function : 	 d_vxpci_set

	A function to set PCI registers for a specific device.  The req_device
	value may be found by calling d_vxpci_display.

*/
int d_vxpci_set( int req_device, int reg, uint32 val, unsigned char numbytes)
{
	int device=0;
	unsigned char byte;
	pci_dev *pDev;
			
	pDev = pci_pListHeadDev;

	while( pDev )
	{
		if( device == req_device )
		{
			break;
		}
		pDev = (pci_dev *)pDev->global_list.next;
		device++;
	}

	if( pDev )
	{
		switch(numbytes)
		{
			case 4:
			pci_write_config_dword( pDev, reg, val );
			break;

			case 2:
			pci_write_config_word( pDev, reg, (uint16)val );
			break;

			default:
			pci_write_config_byte( pDev, reg, (uint8)val );
			break;
		}

		pci_write_config_byte( pDev, reg, val );
		printf("Device %s\n Set Reg: 0x%x = 0x%x\n",pDev->pretty_name, reg, val );
		d_vxpci_get( req_device, reg, numbytes );  
	}
	else
	{
		printf("Error: Unknown device\n");
		printf("Device list:\n");
		d_vxpci_display();
	}

	return 0;
}
	 
/* -------------------------------------------------------
	Function : 	 d_vxpci_get

	A debug function to do a PCI register read for the reqested
	number of bytes.  Returns the register value and prints on the 
	shell.
	For req_device values, use d_vxpci_display
*/
int d_vxpci_get( int req_device, int reg,  unsigned char numbytes )
{
	int device=0;
	uint32	dword;
	uint16	word;
	uint8	byte;
	pci_dev *pDev;
			
	pDev = pci_pListHeadDev;

	while( pDev )
	{
		if( device == req_device )
		{
			break;
		}
		pDev = (pci_dev *)pDev->global_list.next;
		device++;
	}

	if( pDev )
	{
		switch(numbytes)
		{
			case 4:
			pci_read_config_dword( pDev, reg, &dword );
			break;

			case 2:
			pci_read_config_word( pDev, reg, &word );
			dword = word;
			break;

			default:
			pci_read_config_byte( pDev, reg, &byte );
			dword = byte;
			break;
		}

		printf("Device %s\n Read Reg: 0x%x = 0x%x\n",pDev->pretty_name, reg, dword );
	}
	else
	{
		printf("Error: Unknown device\n");
		printf("Device list:\n");
		d_vxpci_display();
	}

	return dword;
}

	
