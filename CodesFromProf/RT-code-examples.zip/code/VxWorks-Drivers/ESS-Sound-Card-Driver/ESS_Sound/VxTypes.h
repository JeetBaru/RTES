/****************************************************************
*
* MODULE:		VxTypes.h
*
* DESCRIPTION: 	A file for resolving function/type accesses from ported linux
*				files to VxWorks
*				
* ORIGINAL AUTHOR: 	Dan Walkes 
*				
* UPDATED BY:		
* 
* CREATED:		Oct, 2005
* MODIFIED:		
* 
* NOTES:
*	General function/type accesses not specific to sound or PCI were placed
*	here.
*
* CODE USAGE:
*	See references
*
* REVISION HISTORY AND NOTES:
*
* Date			Update
* ---------------------------------------------------------------------
* Oct 1, 2005	Created.
*
* REFERENCES:
*
* 1) "vxWALSA Sound Driver" document included with this release.
*
****************************************************************/

#ifndef VXTYPES_H
#define VXTYPES_H

/* VxWorks API includes */
#include "vxWorks.h"
#include "stdio.h"
#include "stdlib.h"
#include "ioLib.h"
#include "semLib.h"
#include "intLib.h"
#include "vmLib.h"   /* added to support */
#include "iv.h"	   
#include "assert.h"
/* pcPentium BSP includes */
#include "sysLib.h"

#include <math.h>
#include <string.h>
#include <syslib.h>
#include <taskLib.h>

/* linux types that are not used with vxWorks */
#define __devinit

/* use this #define to keep functions non-static for debugging purposes */
//#define static

/* debugging #defines */
#define pr_debug	printf
#define printk		logMsg
#define SYS_ASSERT	assert

/* storage types */
typedef unsigned int uint32;
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned long kernel_ulong_t;
typedef unsigned long dma_addr_t;
typedef long long uint64;
typedef void irqreturn_t;
#define IRQ_RETVAL(x) /*void*/
#define THIS_MODULE	0	/* NOT USING MODULES */
#define __devexit_p(x) x	/* use exit functions */
struct list_head {
	struct list_head *next, *prev;
};

#define strlcpy(toaddr,fromaddr,len) memcpy(toaddr,fromaddr,len)	

/* storage #defines */
#define __u32	uint32
#define u16		uint16
#define u64		uint64
#define u_int32_t	uint32

/* spinlock #defines .. use when you need to lock out interrupts and other tasks.. callable
	from interrupt or non-interrupt context */
#define spin_lock_irqsave(lock, flags)	flags = vx_spin_lock_irqsave() 
#define spin_unlock_irqrestore(lock, flags) 	vx_spin_unlock_irqrestore( flags ) 

/* not currently used */
#define spin_lock_init(lock)

/* the spinlock structure (currently unused) */
typedef struct spinlock {
	volatile unsigned int unused;
}spinlock_t; 

#define init_MUTEX(mutexaddr)	

#define udelay(usdelay)	taskDelay( usdelay/1000 ) /* note: may have resolution problems here */

/* other unused value #defines */
typedef struct wait_queue_head {
	int Unused;
}wait_queue_head_t;
#define init_waitqueue_head(unused)

#define INIT_LIST_HEAD(ptr) do { \
	(ptr)->next = (ptr); (ptr)->prev = (ptr); \
} while (0)


/* todo: add better list handling.. these are here mostly to get rid of compile errors*/

/*
 * Insert a new entry between two known consecutive entries.
 *
 * This is only for internal list manipulation where we know
 * the prev/next entries already!
 */
static inline void __list_add(struct list_head *newptr,
			      struct list_head *prev,
			      struct list_head *next)
{
	next->prev = newptr;
	newptr->next = next;
	newptr->prev = prev;
	prev->next = newptr;
}

/**
 * list_add - add a new entry
 * @new: new entry to be added
 * @head: list head to add it after
 *
 * Insert a new entry after the specified head.
 * This is good for implementing stacks.
 */
static inline void list_add(struct list_head *newitm, struct list_head *head)
{
	__list_add(newitm, head, head->next);
}



/**
 * list_add_tail - add a new entry
 * @new: new entry to be added
 * @head: list head to add it before
 *
 * Insert a new entry before the specified head.
 * This is useful for implementing queues.
 */
static inline void list_add_tail(struct list_head *newptr, struct list_head *head)
{
	__list_add(newptr, head->prev, head);
}

/* modified device structure.. only member used is driver_data pointer */
struct device_s {
	void *driver_data;
};


/* success/failure types */
#define SUCCESS_vx	0
#define ERR0R_GEN_FAIL_vx		-1


/* memory type #defines for linux (currently unused)  */
#define GFP_KERNEL
/* -------------------------------------------------- */

/* General linux to VxWorks function mapping #defines  */
#define kcalloc( numtypes, typesize, memspace ) calloc( numtypes , typesize )
#define kfree( addr ) 							free( addr )

/* PCI interrupt defines */
#define INT_NUM_IRQ0	0x20
#define request_irq( irqnum, funcptr, unused1, unused2, param )    vx_pci_request_irq( irqnum, (VOIDFUNCPTR) funcptr, (int) param )
#define free_irq( irqnum, param, funcptr )							vx_pci_free_irq( irqnum, (VOIDFUNCPTR) funcptr )

#define inline 
#define __devexit
/* -------------------------------------------------- */

/* VxWorks/Linux error types */
#define ENOMEM 12
#define ENXIO 	6
#define ENODEV	19
#define ENOENT	2


/* vxLinSupport function prototypes */
int vx_spin_unlock_irqrestore( unsigned long lockKey );
unsigned long vx_spin_lock_irqsave( void );
#endif