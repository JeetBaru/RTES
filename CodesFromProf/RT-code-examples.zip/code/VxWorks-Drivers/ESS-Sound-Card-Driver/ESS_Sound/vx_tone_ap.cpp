/****************************************************************
*
* MODULE:		vx_tone_ap.cpp
*
* DESCRIPTION:	Functions used to test sound card playback and the ALSA-VxWorks 
*				library functions
*
* ORIGINAL AUTHOR: 	Dan Walkes
*					
* UPDATED BY:		
* 
* CREATED:		Oct, 2005
* MODIFIED:		
* 
* NOTES:		Simple ap written to test functionality of sound driver and
*				demonstrate usage
*
*
* CODE USAGE:
*
*	See the VxPCI.cpp module for information about how to install
*	drivers in the system.  Once drivers have been installed, use the function:
*	
*	new_tone( frequency ) to set a new tone frequency for output playback
*
* REVISION HISTORY AND NOTES:
*
* Date			Update
* ---------------------------------------------------------------------
* Oct 1, 2005	Created.
*
* REFERENCES:
*
* 1) "vxWALSA Sound Driver" document included with this release.
*
****************************************************************/

#include "VxTypes.h"
#include "VxPCI.h"
#include "VxSound.h"
#include <math.h>

struct toneApData
{
	uint32 currRate;
	snd_pcm_substream_t *substream;
	double lastRad;
};

toneApData *ptone;

// use this macro to turn on debugging log messages
// #define TONE_AP_DEBUG	logMsg
#ifndef TONE_AP_DEBUG
	#define TONE_AP_DEBUG
#endif

/*--------------------------------------------------------------
	Function Description:
		Initializes the passed toneApData structure based on the passed
		substram
	
	Arguments:
		*substream - a pointer to the substream which is associated with this structure
		*pData - a pointer to the toneAp structure to initialize

	Todo: may want to implement mutexes on the toneApData structure
	
---------------------------------------------------------------*/
void InitToneApData( toneApData *pData,  snd_pcm_substream_t *substream )
{
	pData->lastRad = 0;
	pData->substream = substream;
}


/*--------------------------------------------------------------
	Function Description:
		Writes a tone pattern to the dma buffer for the substream associated with the
		passed toneApData structure.
	
	Arguments:
		toneApData *pData - a pointer to the structure containing substream and
		tone information.

	Todo: may want to implement mutexes on the toneApData structure
	
---------------------------------------------------------------*/
void toneApPattern( toneApData *pData )
{
	snd_pcm_runtime_t *runtime = pData->substream->runtime;
	snd_pcm_substream_t *substream = pData->substream;
	uint8 *pAddr;	// assumes uint8 data
	uint32 size;
	uint32 i=0;
	uint32 maxScale = 0xff;	// assumes uint8 data
	uint8 bUnsigned = TRUE;	// assumes unsigned data
	#define bufelementsize	uint8	// assumes uint8 data
	uint32 curVal;
	double temp;
	uint32 bufPos;
	
	size = runtime->buffer_size/2;

	bufPos = substream->ops->pointer( substream );

	if( bufPos < size )	// this means we are at the beginning of the buffer.. start at the midway point
	{
		pAddr = runtime->dma_area + size;
	}
	else
	{
		// this means we are at the end of the buffer.. start at the halfway point
		pAddr = runtime->dma_area;
	}

	TONE_AP_DEBUG("Buffer pointer = 0x%x, set start addr = 0x%x size = 0x%x",bufPos, pAddr, size);

	for( i=0; i<size; i++ )
	{
		temp = sin( pData->lastRad );
		curVal = (uint32)(maxScale * temp);
		if( bUnsigned )
		{
			curVal /= 2;
			curVal += maxScale/2;  // put in range 0-maxScale
		}		
		TONE_AP_DEBUG("last rad %d\n",pData->lastRad);
		pData->lastRad += 2*3.14*(double)pData->currRate/((double)substream->runtime->rate);
		TONE_AP_DEBUG("next rad %d\n",pData->lastRad);
		if( pData->lastRad > (2*3.14) )
		{
			pData->lastRad -= (2*3.14);
		}
		TONE_AP_DEBUG("next rad %d\n",pData->lastRad);
		*pAddr = (bufelementsize )curVal;
		TONE_AP_DEBUG("bufferval %d\n",curVal);
		pAddr++;
	}
	
}


/*--------------------------------------------------------------
	Function Description:
		Task initialize function to initialize the tone application on
		the passed substream.  
		Spawned as a seperate task by the sound driver.
	
	Arguments:
		*substream - the substream to initialize for tone ap.

	Todo: may want to implement mutexes on the toneApData structure
	
---------------------------------------------------------------*/
void toneApPlaybackTaskInit( snd_pcm_substream_t *substream )
{
	toneApData tone;

	tone.currRate = 10000;	// start with 10khz


	substream->ops->prepare( substream );

	InitToneApData( &tone, substream );
	ptone = &tone;

	printf("triggering playback\n");
	substream->ops->trigger( substream, SNDRV_PCM_TRIGGER_START );
	substream->ops->volume( substream, 0xff );

//	toneApPattern( &tone );

	do
	{
		semTake( substream->sem_period_elapsed, WAIT_FOREVER );
		/* write the next pattern each time the period elapses */
	  	toneApPattern( &tone );
	}while( TRUE );

}

/*--------------------------------------------------------------
	Function Description:
		Function to set a new tone to play on the speaker output (can be called at the shell)
	
	Arguments:
		uint32 freq - the new frequency to set

	Todo: may want to implement mutexes on the toneApData structure
	
---------------------------------------------------------------*/
void new_tone( uint32 freq )
{
	if( freq == 0 || ( freq > ( ptone->substream->runtime->rate/2 ) ) )
	{
		printf("Invalid tone choice.. Max frequency %d\n",ptone->substream->runtime->rate/2 );
	}
	else
	{
		ptone->currRate = freq;
	}
}	

/*--------------------------------------------------------------
	Function Description:
		Function to set a new volume value
	
	Arguments:
		uint32 volval - the new volume level to set

	Todo: may want to implement mutexes on the toneApData structure
	
---------------------------------------------------------------*/

void volume( uint32 volval )
{
	if( volval > 0xff )
	{
		printf("Error, max volume is 0xff\n");
	}
	else
	{
		ptone->substream->ops->volume( ptone->substream, volval );
	}
}

