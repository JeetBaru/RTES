/* tcpExample.h- header used by both TCP server and client examples */

#define PLAYBACK_FILE "/tgtsvr/Audio.out"


#define SERVER_WORK_PRIORITY 5  /* priority of server's work task */
#define SERVER_STACK_SIZE 10000 /* stack size of server's work task */
#define SERVER_MAX_CONNECTIONS 4 /* max clients connected at a time */
#define MAX_LINE 2048 /* max size of data per block */
#define REPLY_MSG_SIZE 500 /* max size of reply message */
#define MAX_REC_BLOCK 10  

void loadBuffer(char b[MAX_LINE]);
