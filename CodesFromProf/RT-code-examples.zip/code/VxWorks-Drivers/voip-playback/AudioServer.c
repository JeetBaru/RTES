/* AudioServer.c - TCP server example */

#include "sys/types.h"
#include "stdio.h"
#include "signal.h"
#include "vxWorks.h" 
#include "taskLib.h"
#include "tcpExample.h"


VOID tcpRecvTask(int sFd);

STATUS tcpServer (int SERVER_PORT_NUM)
{
  char workName[16]; /* name of work task */

  logMsg("before the taskSpawn.\n");
  if (taskSpawn(workName, SERVER_WORK_PRIORITY, 0, SERVER_STACK_SIZE,(FUNCPTR) tcpRecvTask, 0, 0, 0,0,0, 0, 0, 0, 0, 0) == ERROR)
    {
      perror ("taskSpawn");
    }
}




 
