Visio trial can be downloaded from microsoft.com and Visio UML templates can be downloaded from http://www.phruby.com/stencildownload.html.
