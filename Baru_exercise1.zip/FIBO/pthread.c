/* Authors: Jeet Baru  Date: 17-06-2017
   Descriptions: This code makes use of POSIX extensions to schedule two threads to run concurrently, making
   use of Rate Monotonic scheduling.
   Citation: This code has been adapted from Nisheeth Bhat's independent study of RM Scheduling Feasibility Tests 
   conducted on TI DM3730 Processor - 1 GHz ARM Cortex-A8 core with Angstrom and TimeSys Linux ported on to 
   BeagleBoard xM.
*/

#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>
#include <sched.h>
#include <unistd.h>
#include <time.h>
#include <syslog.h>
#include <math.h>
#include <sys/param.h>


/********************************************************************
Variable Declarations
********************************************************************/
pthread_t testThread10;
pthread_t testThread20;
pthread_attr_t rt10_sched_attr;
pthread_attr_t rt20_sched_attr;
pthread_attr_t main_sched_attr;
sem_t sem_t10,sem_t20;
int rt_max_prio, rt_min_prio, min, abortTest_10 = 0,abortTest_20=0;
struct sched_param rt10_param;
struct sched_param rt20_param;
struct sched_param nrt_param;
struct sched_param main_param;

#define FIB_LIMIT_FOR_32_BIT 47
#define NSEC_PER_SEC (1000000000)
#define DELAY_TICKS (1)
#define ERROR (-1)
#define OK (0)

int seqIterations = FIB_LIMIT_FOR_32_BIT;
static struct timespec rtclk_dt = {0, 0};
static struct timespec rtclk_start_time = {0, 0};
static struct timespec rtclk_stop_time = {0, 0};


/********************************************************************
Fibonaci Delay
********************************************************************/
#define FIB_TEST(seqCnt, iterCnt) \
for(idx=0; idx < iterCnt; idx++) \
{\
while(jdx < seqCnt)\
{\
if (jdx == 0)\
{\
fib = 1;\
}\
else\
{\
fib0 = fib1;\
fib1 = fib;\
fib = fib0 + fib1;\
}\
jdx++;\
}\
}

//function to compute difference between start and stop times
int delta_t(struct timespec *stop, struct timespec *start, struct timespec *delta_t)
{
  int dt_sec=stop->tv_sec - start->tv_sec;
  int dt_nsec=stop->tv_nsec - start->tv_nsec;

  if(dt_sec >= 0)
  {
    if(dt_nsec >= 0)
    {
      delta_t->tv_sec=dt_sec;
      delta_t->tv_nsec=dt_nsec;
    }
    else
    {
      delta_t->tv_sec=dt_sec-1;
      delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
    }
  }
  
  else
  {
    if(dt_nsec >= 0)
    {
      delta_t->tv_sec=dt_sec;
      delta_t->tv_nsec=dt_nsec;
    }
    else
    {
      delta_t->tv_sec=dt_sec-1;
      delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
    }
  }

  return(OK);
}


// Simply prints the current POSIX scheduling policy in effect.
//
void print_scheduler (void)
{
int schedType;
schedType = sched_getscheduler(getpid());
switch(schedType)
{
case SCHED_FIFO:
printf("Pthread Policy is SCHED_FIFO\n");
break;
case SCHED_OTHER:
printf("Pthread Policy is SCHED_OTHER\n");
break;
case SCHED_RR:
printf("Pthread Policy is SCHED_OTHER\n");
break;
default:
printf("Pthread Policy is UNKNOWN\n");
}
}


/********************************************************************
Threads
********************************************************************/

void *Fib10(void *threadid)
{
struct sched_param param;
int policy;
double duration ;
int idx = 0, jdx = 1;
int fib = 0, fib0 = 0, fib1 = 1;
unsigned long mask = 1; /* processor 0 */
/* bind process to processor 0 */
while (!abortTest_10)
{
    sem_wait (& sem_t10 );
    if ( pthread_setaffinity_np ( pthread_self (), sizeof ( mask ),&mask ) < 0 )
    {
        perror("pthread_setaffinity_np");
    }
    FIB_TEST(seqIterations, 442000);
    clock_gettime(CLOCK_REALTIME, &rtclk_stop_time);
    delta_t(&rtclk_stop_time, &rtclk_start_time, &rtclk_dt);

    pthread_getschedparam(testThread10,&policy ,&param);
    printf("Fib10 priority = %d and time stamp %lf msec\n", param.sched_priority,(double)(rtclk_dt.tv_nsec/1000000.0));
}
}

void *Fib20(void *threadid)
{
struct sched_param param;
int policy;
int idx = 0, jdx = 1;
int fib = 0, fib0 = 0, fib1 = 1;
double duration ;

while (!abortTest_20)
{
    sem_wait (& sem_t20 );
    unsigned long mask = 1; /* processor 0 */   
    if ( pthread_setaffinity_np ( pthread_self (), sizeof ( mask ),& mask ) < 0 )
    {
        perror("pthread_setaffinity_np");
    }
    FIB_TEST(seqIterations, 884000);
    clock_gettime(CLOCK_REALTIME, &rtclk_stop_time);
    delta_t(&rtclk_stop_time, &rtclk_start_time, &rtclk_dt);
    pthread_getschedparam(testThread20,&policy ,&param);
    printf("Fib20 priority = %d and time stamp %lf msec\n",param.sched_priority,(double)(rtclk_dt.tv_nsec/1000000.0));
}
}


/********************************************************************
Main
********************************************************************/

int main (int argc, char *argv[])
{
int rc , scope , i ;
useconds_t t_10,t_20;
sem_init (& sem_t10 , 0 , 1 );
sem_init (& sem_t20 , 0 , 1 );
double stop_1 = 0;
t_10 = 10000;
t_20 = 20000;
printf("Before adjustments to scheduling policy:\n");
print_scheduler();

// We set all threads to be run to completion at high
// priority so that we can determine whether the hardware
// provides speed-up by mapping threads onto multiple cores
// and/or SMT (Symmetric Multi-threading) on each core.

pthread_attr_init (&rt10_sched_attr);
pthread_attr_init (&rt20_sched_attr);
pthread_attr_init (&main_sched_attr);
pthread_attr_setinheritsched (&rt10_sched_attr, PTHREAD_EXPLICIT_SCHED);
pthread_attr_setschedpolicy (&rt10_sched_attr, SCHED_FIFO);
pthread_attr_setinheritsched (&rt20_sched_attr, PTHREAD_EXPLICIT_SCHED);
pthread_attr_setschedpolicy (&rt20_sched_attr, SCHED_FIFO);
pthread_attr_setinheritsched (&main_sched_attr, PTHREAD_EXPLICIT_SCHED);
pthread_attr_setschedpolicy (&main_sched_attr, SCHED_FIFO);
rt_max_prio = sched_get_priority_max (SCHED_FIFO);
rt_min_prio = sched_get_priority_min (SCHED_FIFO);
rc=sched_getparam (getpid(), &nrt_param);
main_param.sched_priority = rt_max_prio;
rt10_param.sched_priority = rt_max_prio-1;
rt20_param.sched_priority = rt_max_prio-2;
rc=sched_setscheduler(getpid(), SCHED_FIFO, &main_param);
if (rc)
{
    printf("ERROR; sched_setscheduler rc is %d\n", rc); 
    perror(NULL); 
    exit(-1);
}

printf("After adjustments to scheduling policy:\n");
print_scheduler();
printf("min prio = %d, max prio = %d\n", rt_min_prio, rt_max_prio);
pthread_attr_getscope (&rt10_sched_attr, &scope);

// Check the scope of the POSIX scheduling mechanism
if(scope == PTHREAD_SCOPE_SYSTEM)
printf("PTHREAD SCOPE SYSTEM\n");
else if (scope == PTHREAD_SCOPE_PROCESS)
printf("PTHREAD SCOPE PROCESS\n");
else
printf("PTHREAD SCOPE UNKNOWN\n");


pthread_attr_setschedparam (&rt10_sched_attr, &rt10_param);
pthread_attr_setschedparam (&rt20_sched_attr, &rt20_param);
pthread_attr_setschedparam (&main_sched_attr, &main_param);

clock_gettime(CLOCK_REALTIME, &rtclk_start_time);;
rc = pthread_create (& testThread10 , & rt10_sched_attr , Fib10 , ( void *) 0 );
if (rc)
{
    printf("ERROR; pthread_create() rc is %d\n", rc); 
    perror(NULL); 
    exit(-1);
}

rc = pthread_create (& testThread20 , & rt20_sched_attr , Fib20 , ( void *) 0 );
if (rc)
{
    printf("ERROR; pthread_create() rc is %d\n", rc); 
    perror(NULL); 
    exit(-1);
}

/* Basic sequence of releases after CI */
usleep ( t_20 );
sem_post (& sem_t10 );
usleep ( t_20 );
sem_post (& sem_t10 );
usleep ( t_10 );
abortTest_20 = 1;
sem_post (& sem_t20 );
usleep ( t_10 );
sem_post (& sem_t10 );
usleep ( t_20 );
abortTest_10 = 1;
sem_post (& sem_t10 );
usleep ( t_20 );
clock_gettime(CLOCK_REALTIME, &rtclk_stop_time);
delta_t(&rtclk_stop_time, &rtclk_start_time, &rtclk_dt);

printf("Test Conducted over %lf msec\n",(double)(rtclk_dt.tv_nsec/1000000.0));

//Join the threads
pthread_join ( testThread10 , NULL );
pthread_join ( testThread20 , NULL );

if(pthread_attr_destroy(&rt10_sched_attr) != 0)
    perror("attr destroy");
if(pthread_attr_destroy(&rt20_sched_attr) != 0)
    perror("attr destroy");
    
sem_destroy(&sem_t10);
sem_destroy(&sem_t20);

rc=sched_setscheduler(getpid(), SCHED_OTHER, &nrt_param);
printf("TEST COMPLETE\n");

}
